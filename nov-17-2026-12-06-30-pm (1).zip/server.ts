import dotenv from 'dotenv';
import express from 'express';
import fs from 'fs';
import JSZip from 'jszip';
import path from 'path';
import {createServer as createViteServer} from 'vite';
import {RubikaBotEngine} from './server/botEngine.js';
import {musicCatalog} from './server/musicCatalog.js';
import {searchMusicReal} from './server/musicService.js';
import {generateProjectExportFiles} from './server/pythonTemplates.js';
import {discoverTrendingRubikaSongs} from './server/trendingService.js';
import {MusicMood, Track, UserRole} from './src/types/bot.js';

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;
  const engine = new RubikaBotEngine();

  // Warm up 1,000+ song catalog (شاد / غمگین / لری / سنتی / پاپ / نوستالژی) in background
  void musicCatalog.ensureHydrated(1200);

  app.use(express.json({limit: '4mb'}));

  // 1. Get full persisted bot state
  app.get('/api/state', (_req, res) => {
    res.json(engine.getState());
  });

  // 1b. Get real 24-hour Voice Chat playback & peak bot usage analytics
  app.get('/api/analytics', (req, res) => {
    const state = engine.getState();
    const groupId = String(req.query.groupId || state.activeGroupId);
    const rawTz = req.query.tzOffset;
    const tzOffset =
      rawTz !== undefined && rawTz !== '' && Number.isFinite(Number(rawTz))
        ? Number(rawTz)
        : undefined;
    const analytics = engine.getGroupAnalytics(groupId, tzOffset);
    if (!analytics) {
      res.status(404).json({error: 'گروه پیدا نشد.'});
      return;
    }
    res.json(analytics);
  });

  // 2. Update token, creator name, mode, or active group
  app.post('/api/config', (req, res) => {
    const body = req.body as {
      token?: string;
      creatorName?: string;
      botName?: string;
      rubikaMode?: 'bot_api_v3' | 'userbot_rubpy';
      activeGroupId?: string;
    };
    const updated = engine.updateConfig(body);
    res.json(updated);
  });

  // 3. Real Rubika Bot API v3 token verification (getMe)
  app.post('/api/bot/verify', async (_req, res) => {
    const result = await engine.verifyToken();
    res.json({
      result,
      state: engine.getState(),
    });
  });

  // 4. Start or stop real Rubika getUpdates polling loop
  app.post('/api/bot/polling', (req, res) => {
    const {action} = req.body as {action?: 'start' | 'stop'};
    const updated = action === 'start' ? engine.startPolling() : engine.stopPolling();
    res.json(updated);
  });

  // 5. Send a direct real message to a Rubika chat_id
  app.post('/api/bot/send-rubika', async (req, res) => {
    const {chatId, text, replyToMessageId} = req.body as {
      chatId: string;
      text: string;
      replyToMessageId?: string;
    };
    if (!chatId || !text) {
      res.status(400).json({ok: false, error: 'شناسه چت و متن پیام الزامی است.'});
      return;
    }
    const apiRes = await engine.callRubikaApi('sendMessage', {
      chat_id: chatId,
      text,
      ...(replyToMessageId ? {reply_to_message_id: replyToMessageId} : {}),
    });
    res.json({
      ...apiRes,
      state: engine.getState(),
    });
  });

  // 6. Incoming Rubika Bot API Webhook receiver
  app.post('/api/rubika/webhook', async (req, res) => {
    const payload = req.body as Record<string, unknown>;
    if (payload.new_message && typeof payload.new_message === 'object') {
      await engine.handleIncomingRubikaUpdate(payload.new_message as Record<string, unknown>);
    } else if (payload.text && payload.chat_id) {
      await engine.handleIncomingRubikaUpdate(payload);
    }
    res.json({ok: true});
  });

  // 7. Execute any Persian Bot Command in a group (with optional Rubika delivery)
  app.post('/api/command', async (req, res) => {
    const body = req.body as {
      groupId?: string;
      senderId?: string;
      senderName?: string;
      text?: string;
      replyToMessageId?: string;
      replyToSenderId?: string;
      replyToAudioUrl?: string;
      replyToTitle?: string;
      sendToRubika?: boolean;
    };
    if (!body.text || !body.text.trim()) {
      res.status(400).json({error: 'متن دستور خالی است.'});
      return;
    }
    const state = engine.getState();
    const result = await engine.executeCommand({
      groupId: body.groupId || state.activeGroupId,
      senderId: body.senderId || state.creatorId,
      senderName: body.senderName,
      text: body.text,
      replyToMessageId: body.replyToMessageId,
      replyToSenderId: body.replyToSenderId,
      replyToAudioUrl: body.replyToAudioUrl,
      replyToTitle: body.replyToTitle,
      sendToRubika: Boolean(body.sendToRubika),
    });
    res.json({
      ...result,
      state: engine.getState(),
    });
  });

  // 8. Real live music search (iTunes + Deezer + Local 1000+ catalog)
  app.get('/api/music/search', async (req, res) => {
    const q = String(req.query.q || '').trim();
    if (!q) {
      res.json({tracks: []});
      return;
    }
    const tracks = await searchMusicReal(q, String(req.query.by || 'کاربر'));
    res.json({tracks});
  });

  // 8b. Query 1,000+ categorized song catalog (شاد / غمگین / محلی و لری / سنتی / پاپ / نوستالژی / آرام)
  app.get('/api/music/catalog', (req, res) => {
    const mood = String(req.query.mood || 'همه');
    const q = String(req.query.q || '');
    const offset = Number(req.query.offset || 0);
    const limit = Number(req.query.limit || 40);
    res.json(musicCatalog.queryCatalog({mood, q, offset, limit}));
  });

  // 8c. Expand/sync more songs into the catalog
  app.post('/api/music/catalog/sync', async (req, res) => {
    const body = (req.body || {}) as {targetCount?: number};
    const current = musicCatalog.getStats().total;
    const target = body.targetCount || Math.max(1200, current + 300);
    const result = await musicCatalog.syncCatalog(target);
    res.json({
      ...result,
      stats: musicCatalog.getStats(),
    });
  });

  // 8d. Pick & enqueue N random tracks from a mood (شاد / غمگین / etc.)
  app.post('/api/music/catalog/enqueue-mood', (req, res) => {
    const {groupId, mood, count} = req.body as {
      groupId?: string;
      mood?: MusicMood;
      count?: number;
    };
    const state = engine.getState();
    const picked = musicCatalog.pickRandom(mood, Math.min(50, Math.max(1, count || 10)), state.creatorName);
    if (picked.length === 0) {
      res.status(404).json({error: 'هنوز آهنگی در این دسته‌بندی آماده نشده است.'});
      return;
    }
    engine.enqueueBulkTracks(groupId || state.activeGroupId, picked, mood);
    res.json({
      addedCount: picked.length,
      state: engine.getState(),
    });
  });

  // 8e. Preview a multi-genre smart playlist mix before applying
  app.post('/api/music/catalog/smart-playlist/preview', (req, res) => {
    const {moods, count, balanceMode} = req.body as {
      moods?: MusicMood[];
      count?: number;
      balanceMode?: 'interleaved' | 'shuffled';
    };
    const state = engine.getState();
    const result = musicCatalog.buildSmartMix({
      moods: moods && moods.length > 0 ? moods : ['شاد', 'غمگین'],
      totalCount: count || 20,
      balanceMode: balanceMode || 'interleaved',
      requestedBy: state.creatorName,
    });
    res.json(result);
  });

  // 8f. Build and start/enqueue a multi-genre smart playlist in Voice Chat
  app.post('/api/music/catalog/smart-playlist', (req, res) => {
    const {groupId, name, moods, count, balanceMode, startMode, savePreset, customTracks} =
      req.body as {
        groupId?: string;
        name?: string;
        moods?: MusicMood[];
        count?: number;
        balanceMode?: 'interleaved' | 'shuffled';
        startMode?: 'replace_and_play' | 'append_queue';
        savePreset?: boolean;
        customTracks?: Track[];
      };
    const state = engine.getState();
    const targetGroupId = groupId || state.activeGroupId;
    const selectedMoods: MusicMood[] = moods && moods.length > 0 ? moods : ['شاد', 'غمگین'];

    const mix =
      customTracks && customTracks.length > 0
        ? {tracks: customTracks, breakdown: {}}
        : musicCatalog.buildSmartMix({
            moods: selectedMoods,
            totalCount: count || 20,
            balanceMode: balanceMode || 'interleaved',
            requestedBy: state.creatorName,
          });

    if (mix.tracks.length === 0) {
      res.status(404).json({error: 'آهنگی برای این ترکیب یافت نشد.'});
      return;
    }

    const finalName = name?.trim() || `میکس هوشمند: ${selectedMoods.join(' + ')}`;
    engine.applySmartPlaylist(targetGroupId, {
      name: finalName,
      moods: selectedMoods,
      tracks: mix.tracks,
      balanceMode: balanceMode || 'interleaved',
      startMode: startMode || 'replace_and_play',
      savePreset: Boolean(savePreset),
    });

    res.json({
      addedCount: mix.tracks.length,
      breakdown: mix.breakdown,
      state: engine.getState(),
    });
  });

  // 8g. Delete a saved smart playlist preset
  app.delete('/api/groups/:groupId/playlists/:playlistId', (req, res) => {
    const {groupId, playlistId} = req.params;
    const updatedGroup = engine.deleteSavedPlaylist(groupId, playlistId);
    if (!updatedGroup) {
      res.status(404).json({error: 'گروه پیدا نشد.'});
      return;
    }
    res.json({state: engine.getState()});
  });

  // 8h. Online discovery of today's most popular Rubika songs (Google Search Grounding + playable stream resolution)
  app.post('/api/music/trending-rubika', async (_req, res) => {
    try {
      const result = await discoverTrendingRubikaSongs();
      res.json(result);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'خطا در جستجوی آنلاین آهنگ‌های محبوب روز.';
      res.status(500).json({error: message});
    }
  });

  // 9. CORS-clean real audio stream proxy for Web Audio API Voice Call playback & visualizer
  app.get('/api/music/stream', async (req, res) => {
    const targetUrl = String(req.query.url || '').trim();
    if (!targetUrl) {
      res.status(400).send('Missing url');
      return;
    }
    try {
      const parsed = new URL(targetUrl);
      if (!['http:', 'https:'].includes(parsed.protocol)) {
        res.status(400).send('Invalid protocol');
        return;
      }
      const headers: Record<string, string> = {
        'User-Agent': 'ParyaRubikaMusicBot/1.0',
      };
      if (req.headers.range) {
        headers.Range = String(req.headers.range);
      }
      const upstream = await fetch(parsed.toString(), {
        headers,
        signal: AbortSignal.timeout(15000),
      });
      if (!upstream.ok && upstream.status !== 206) {
        res.status(upstream.status).send('Upstream audio error');
        return;
      }
      const contentType = upstream.headers.get('content-type') || 'audio/mpeg';
      const contentLength = upstream.headers.get('content-length');
      const contentRange = upstream.headers.get('content-range');
      res.status(upstream.status);
      res.setHeader('Content-Type', contentType);
      res.setHeader('Accept-Ranges', 'bytes');
      res.setHeader('Access-Control-Allow-Origin', '*');
      if (contentLength) res.setHeader('Content-Length', contentLength);
      if (contentRange) res.setHeader('Content-Range', contentRange);

      const arrayBuf = await upstream.arrayBuffer();
      res.send(Buffer.from(arrayBuf));
    } catch {
      res.status(502).send('Failed to stream audio');
    }
  });

  // 10. Play or enqueue a specific searched track
  app.post('/api/player/select-track', (req, res) => {
    const {groupId, track, mode} = req.body as {
      groupId?: string;
      track?: Track;
      mode?: 'play_now' | 'queue';
    };
    if (!track) {
      res.status(400).json({error: 'اطلاعات آهنگ ارسال نشده است.'});
      return;
    }
    const state = engine.getState();
    engine.playSpecificTrack(groupId || state.activeGroupId, track, mode || 'play_now');
    res.json(engine.getState());
  });

  // 11. Track ended -> advance queue
  app.post('/api/player/ended', (req, res) => {
    const {groupId} = req.body as {groupId?: string};
    const state = engine.getState();
    engine.handleTrackEnded(groupId || state.activeGroupId);
    res.json(engine.getState());
  });

  // 12. Add or update Rubika group
  app.post('/api/groups', (req, res) => {
    const body = req.body as {
      groupId?: string;
      title: string;
      rubikaChatId: string;
      daysValid?: number;
    };
    if (!body.title || !body.rubikaChatId) {
      res.status(400).json({error: 'نام گروه و شناسه چت روبیکا الزامی است.'});
      return;
    }
    const group = engine.addOrUpdateGroup(body);
    res.json({group, state: engine.getState()});
  });

  // 13. Add / update member inside a group
  app.post('/api/groups/:groupId/members', (req, res) => {
    const {groupId} = req.params;
    const {name, userId, role} = req.body as {
      name: string;
      userId: string;
      role?: UserRole;
    };
    if (!name || !userId) {
      res.status(400).json({error: 'نام و شناسه کاربر الزامی است.'});
      return;
    }
    const group = engine.addMemberToGroup(groupId, name, userId, role || 'member');
    if (!group) {
      res.status(404).json({error: 'گروه پیدا نشد.'});
      return;
    }
    res.json({group, state: engine.getState()});
  });

  // 13b. Configure automatic Voice Call shutdown time (خاموشی خودکار ربات)
  app.post('/api/groups/:groupId/auto-shutdown', (req, res) => {
    const {groupId} = req.params;
    const {enabled, targetTime, timezoneOffsetMinutes, stopPollingAlso} = req.body as {
      enabled: boolean;
      targetTime: string;
      timezoneOffsetMinutes?: number;
      stopPollingAlso?: boolean;
    };
    const group = engine.setGroupAutoShutdown(groupId, {
      enabled: Boolean(enabled),
      targetTime: String(targetTime || '23:30'),
      timezoneOffsetMinutes,
      stopPollingAlso: Boolean(stopPollingAlso),
    });
    if (!group) {
      res.status(404).json({error: 'گروه پیدا نشد.'});
      return;
    }
    res.json({group, state: engine.getState()});
  });

  // 14. Export Python Bot + Buildozer + GitHub Actions files (JSON preview)
  app.get('/api/export/files', (_req, res) => {
    const state = engine.getState();
    const activeGroup = state.groups[state.activeGroupId];
    const files = generateProjectExportFiles({
      token: state.token,
      creatorName: state.creatorName,
      creatorId: state.creatorId,
      defaultGroupTitle: activeGroup?.title || 'گروه موزیکال اصلی',
    });
    res.json({files});
  });

  // 15. Download ready-to-push GitHub repository + APK Buildozer bundle (.zip)
  app.get('/api/export/github-apk-zip', async (_req, res) => {
    const state = engine.getState();
    const activeGroup = state.groups[state.activeGroupId];
    const files = generateProjectExportFiles({
      token: state.token,
      creatorName: state.creatorName,
      creatorId: state.creatorId,
      defaultGroupTitle: activeGroup?.title || 'گروه موزیکال اصلی',
    });

    const zip = new JSZip();
    for (const f of files) {
      zip.file(f.path, f.content);
    }
    const buffer = await zip.generateAsync({type: 'nodebuffer', compression: 'DEFLATE'});
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="parya-rubika-music-bot-apk-github.zip"');
    res.send(buffer);
  });

  // Vite middleware (dev) or static dist serving (prod)
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: {middlewareMode: true},
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (_req, res) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    }
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Parya Rubika Music Bot server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Server failed to start:', err);
  process.exit(1);
});
