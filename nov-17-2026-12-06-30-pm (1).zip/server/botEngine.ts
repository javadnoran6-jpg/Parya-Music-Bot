import fs from 'fs';
import path from 'path';
import {
  AutoShutdownConfig,
  BotConfigState,
  ChatMessage,
  GroupAnalyticsResponse,
  GroupMember,
  GroupState,
  HourlyAnalyticsBucket,
  MusicMood,
  PlaybackAnalyticsEvent,
  RubikaApiLog,
  SmartPlaylistPreset,
  Track,
  UserRole,
} from '../src/types/bot.js';
import {musicCatalog} from './musicCatalog.js';
import {buildTrackFromDirectUrl, searchMusicReal} from './musicService.js';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const STATE_FILE = path.join(DATA_DIR, 'bot-state.json');

const DEFAULT_TOKEN = 'CJFFDA0WCQMQSPUXDCLPUEFXXXEJUPDVGQKGDHKRROFEOMELUTEJNDFUBPUQYSUU';
const DEFAULT_CREATOR_NAME = 'پریا چش رنگی';
const DEFAULT_CREATOR_ID = 'u0_parya_creator';

function addDaysIso(base: Date, days: number): string {
  const d = new Date(base.getTime());
  d.setDate(d.getDate() + days);
  return d.toISOString();
}

function createInitialState(): BotConfigState {
  const now = new Date();
  const mainGroupId = 'g_main_rubika';
  const initialMembers: GroupMember[] = [
    {
      userId: DEFAULT_CREATOR_ID,
      name: DEFAULT_CREATOR_NAME,
      username: '@parya_chesh_rangi',
      role: 'creator',
      joinedAt: now.toISOString(),
    },
    {
      userId: 'u_owner_1',
      name: 'امیرحسین (مالک گروه)',
      username: '@amir_owner',
      role: 'owner',
      joinedAt: now.toISOString(),
    },
    {
      userId: 'u_admin_1',
      name: 'سارا (ادمین)',
      username: '@sara_admin',
      role: 'admin',
      joinedAt: now.toISOString(),
    },
    {
      userId: 'u_vip_1',
      name: 'نیما (کاربر ویژه)',
      username: '@nima_vip',
      role: 'vip',
      joinedAt: now.toISOString(),
    },
    {
      userId: 'u_member_1',
      name: 'مهدی (عضو عادی)',
      username: '@mehdi_user',
      role: 'member',
      joinedAt: now.toISOString(),
    },
  ];

  const mainGroup: GroupState = {
    groupId: mainGroupId,
    title: 'گروه موزیکال اصلی روبیکا',
    rubikaChatId: 'g0D8xP912RubikaMain',
    ownerId: 'u_owner_1',
    ownerName: 'امیرحسین (مالک گروه)',
    publicAccess: 'open',
    voiceCallActive: false,
    volume: 80,
    isMuted: false,
    isPlaying: false,
    currentTrack: null,
    pausedTrack: null,
    pausedPositionSec: 0,
    queue: [],
    history: [],
    members: initialMembers,
    subscription: {
      planName: 'اشتراک ویژه ویسکال نامحدود',
      purchasedAt: addDaysIso(now, -5),
      expiresAt: addDaysIso(now, 25),
      isActive: true,
    },
    messages: [
      {
        id: 'msg_welcome_1',
        groupId: mainGroupId,
        senderId: 'bot_rubika',
        senderName: 'ربات موزیکال روبیکا',
        senderRole: 'creator',
        text: `🎵 ربات موزیکال پیشرفته روبیکا آماده به کار است.\n👑 سازنده: ${DEFAULT_CREATOR_NAME}\nبرای دریافت لیست کامل دستورات کلمه «راهنما» یا برای پخش موسیقی «آهنگ لری» را ارسال کنید.`,
        isBot: true,
        timestamp: now.toISOString(),
      },
    ],
  };

  return {
    token: DEFAULT_TOKEN,
    creatorId: DEFAULT_CREATOR_ID,
    creatorName: DEFAULT_CREATOR_NAME,
    botUsername: '@ParyaMusicBot',
    botName: 'ربات موزیکال پریا چش رنگی',
    pollingActive: false,
    lastVerifyResult: {
      verified: false,
    },
    rubikaMode: 'bot_api_v3',
    activeGroupId: mainGroupId,
    groups: {
      [mainGroupId]: mainGroup,
    },
    apiLogs: [
      {
        id: `log_${Date.now()}`,
        timestamp: now.toISOString(),
        method: 'INIT',
        status: 'info',
        detail: `موتور ربات با توکن ${DEFAULT_TOKEN.slice(0, 10)}... و سازنده ${DEFAULT_CREATOR_NAME} آماده شد.`,
      },
    ],
  };
}

export class RubikaBotEngine {
  private state: BotConfigState;
  private pollingTimer: NodeJS.Timeout | null = null;
  private pollingOffset: string | undefined;
  private isPollingBusy = false;
  private shutdownTicker: NodeJS.Timeout | null = null;

  constructor() {
    this.state = this.loadState();
    // Always ensure pollingActive resets cleanly on server boot
    this.state.pollingActive = false;
    this.saveState();
    this.shutdownTicker = setInterval(() => {
      void this.checkAutoShutdowns();
    }, 4000);
  }

  private normalizeDigits(input: string): string {
    return input
      .replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
      .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));
  }

  private computeNextTriggerIso(targetTime: string, timezoneOffsetMinutes: number): string | null {
    const match = /^([01]?\d|2[0-3]):([0-5]\d)$/.exec(this.normalizeDigits(targetTime.trim()));
    if (!match) return null;
    const hours = Number(match[1]);
    const minutes = Number(match[2]);

    // Convert current UTC epoch to user's local clock by subtracting timezoneOffsetMinutes (e.g. Iran UTC+3:30 => offset -210)
    const nowUtcMs = Date.now();
    const userOffsetMs = timezoneOffsetMinutes * 60 * 1000;
    const userLocalNow = new Date(nowUtcMs - userOffsetMs);

    const targetLocal = new Date(userLocalNow.getTime());
    targetLocal.setUTCHours(hours, minutes, 0, 0);

    let triggerUtcMs = targetLocal.getTime() + userOffsetMs;
    if (triggerUtcMs <= nowUtcMs + 1000) {
      triggerUtcMs += 24 * 60 * 60 * 1000;
    }
    return new Date(triggerUtcMs).toISOString();
  }

  public setGroupAutoShutdown(
    groupId: string,
    input: {
      enabled: boolean;
      targetTime: string;
      timezoneOffsetMinutes?: number;
      stopPollingAlso?: boolean;
    },
  ): GroupState | null {
    const group = this.state.groups[groupId];
    if (!group) return null;

    const tzOffset =
      typeof input.timezoneOffsetMinutes === 'number' && Number.isFinite(input.timezoneOffsetMinutes)
        ? input.timezoneOffsetMinutes
        : new Date().getTimezoneOffset();
    const normalizedTime = this.normalizeDigits(input.targetTime.trim());
    const nextIso = input.enabled ? this.computeNextTriggerIso(normalizedTime, tzOffset) : null;

    const configObj: AutoShutdownConfig = {
      enabled: Boolean(input.enabled && nextIso),
      targetTime: normalizedTime,
      timezoneOffsetMinutes: tzOffset,
      stopPollingAlso: Boolean(input.stopPollingAlso),
      nextTriggerIso: nextIso,
      lastTriggeredAt: group.autoShutdown?.lastTriggeredAt || null,
    };

    group.autoShutdown = configObj;
    const msgText = configObj.enabled
      ? `⏰ تایمر خاموشی خودکار ویسکال روی ساعت ${configObj.targetTime} تنظیم شد.${configObj.stopPollingAlso ? ' (همراه با توقف کامل ربات)' : ''}`
      : '⏰ تایمر خاموشی خودکار ویسکال لغو شد.';

    const infoMsg: ChatMessage = {
      id: `b_${Date.now()}`,
      groupId: group.groupId,
      senderId: 'bot_rubika',
      senderName: this.state.botName,
      senderRole: 'creator',
      text: msgText,
      isBot: true,
      timestamp: new Date().toISOString(),
    };
    group.messages = [...group.messages, infoMsg].slice(-120);
    this.addLog('AUTO_SHUTDOWN_SET', 'info', `${group.title}: ${msgText}`);
    this.saveState();
    return group;
  }

  private async checkAutoShutdowns(): Promise<void> {
    const nowMs = Date.now();
    let changed = false;

    for (const group of Object.values(this.state.groups)) {
      const cfg = group.autoShutdown;
      if (!cfg || !cfg.enabled || !cfg.nextTriggerIso) continue;

      const triggerMs = new Date(cfg.nextTriggerIso).getTime();
      if (!Number.isFinite(triggerMs) || nowMs < triggerMs) continue;

      // Trigger real shutdown for this group
      if (group.currentTrack) {
        group.pausedTrack = group.currentTrack;
        group.currentTrack = null;
      }
      group.isPlaying = false;
      group.voiceCallActive = false;
      cfg.enabled = false;
      cfg.nextTriggerIso = null;
      cfg.lastTriggeredAt = new Date(nowMs).toISOString();

      const shutdownText = `⏰ زمان خودکار (${cfg.targetTime}) فرا رسید: ویسکال قطع و پخش آهنگ متوقف شد.${cfg.stopPollingAlso ? '\n🔴 ربات به صورت کامل خاموش گردید.' : ''}`;

      const botMsg: ChatMessage = {
        id: `b_shutdown_${nowMs}`,
        groupId: group.groupId,
        senderId: 'bot_rubika',
        senderName: this.state.botName,
        senderRole: 'creator',
        text: shutdownText,
        isBot: true,
        timestamp: new Date(nowMs).toISOString(),
      };
      group.messages = [...group.messages, botMsg].slice(-120);
      this.addLog('AUTO_SHUTDOWN_TRIGGER', 'info', `قطع خودکار ویسکال گروه «${group.title}» در ساعت ${cfg.targetTime}`);

      if (this.state.pollingActive && group.rubikaChatId) {
        await this.callRubikaApi('sendMessage', {
          chat_id: group.rubikaChatId,
          text: shutdownText,
        });
      }

      if (cfg.stopPollingAlso && this.state.pollingActive) {
        this.stopPolling();
      }
      changed = true;
    }

    if (changed) {
      this.saveState();
    }
  }

  private loadState(): BotConfigState {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, {recursive: true});
      }
      if (fs.existsSync(STATE_FILE)) {
        const raw = fs.readFileSync(STATE_FILE, 'utf-8');
        const parsed = JSON.parse(raw) as BotConfigState;
        if (parsed && parsed.groups && Object.keys(parsed.groups).length > 0) {
          return parsed;
        }
      }
    } catch {
      // Fallback to fresh state
    }
    return createInitialState();
  }

  private saveState(): void {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, {recursive: true});
      }
      fs.writeFileSync(STATE_FILE, JSON.stringify(this.state, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to persist bot state:', err);
    }
  }

  private addLog(method: string, status: RubikaApiLog['status'], detail: string): void {
    const entry: RubikaApiLog = {
      id: `log_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      timestamp: new Date().toISOString(),
      method,
      status,
      detail,
    };
    this.state.apiLogs = [entry, ...this.state.apiLogs].slice(0, 80);
    this.saveState();
  }

  public getState(): BotConfigState {
    return this.state;
  }

  public updateConfig(patch: {
    token?: string;
    creatorName?: string;
    botName?: string;
    rubikaMode?: 'bot_api_v3' | 'userbot_rubpy';
    activeGroupId?: string;
  }): BotConfigState {
    if (patch.token && patch.token.trim()) {
      this.state.token = patch.token.trim();
      this.state.lastVerifyResult = {verified: false};
    }
    if (patch.creatorName && patch.creatorName.trim()) {
      this.state.creatorName = patch.creatorName.trim();
    }
    if (patch.botName && patch.botName.trim()) {
      this.state.botName = patch.botName.trim();
    }
    if (patch.rubikaMode) {
      this.state.rubikaMode = patch.rubikaMode;
    }
    if (patch.activeGroupId && this.state.groups[patch.activeGroupId]) {
      this.state.activeGroupId = patch.activeGroupId;
    }
    this.saveState();
    return this.state;
  }

  public addOrUpdateGroup(input: {
    groupId?: string;
    title: string;
    rubikaChatId: string;
    ownerId?: string;
    ownerName?: string;
    daysValid?: number;
  }): GroupState {
    const id = input.groupId || `grp_${Date.now()}`;
    const now = new Date();
    const days = Math.max(1, input.daysValid || 30);
    const existing = this.state.groups[id];

    const group: GroupState = existing
      ? {
          ...existing,
          title: input.title.trim() || existing.title,
          rubikaChatId: input.rubikaChatId.trim() || existing.rubikaChatId,
        }
      : {
          groupId: id,
          title: input.title.trim() || 'گروه جدید روبیکا',
          rubikaChatId: input.rubikaChatId.trim(),
          ownerId: input.ownerId || this.state.creatorId,
          ownerName: input.ownerName || this.state.creatorName,
          publicAccess: 'open',
          voiceCallActive: false,
          volume: 80,
          isMuted: false,
          isPlaying: false,
          currentTrack: null,
          pausedTrack: null,
          pausedPositionSec: 0,
          queue: [],
          history: [],
          members: [
            {
              userId: this.state.creatorId,
              name: this.state.creatorName,
              role: 'creator',
              joinedAt: now.toISOString(),
            },
          ],
          subscription: {
            planName: 'اشتراک ویژه ویسکال',
            purchasedAt: now.toISOString(),
            expiresAt: addDaysIso(now, days),
            isActive: true,
          },
          messages: [
            {
              id: `msg_${Date.now()}`,
              groupId: id,
              senderId: 'bot_rubika',
              senderName: this.state.botName,
              senderRole: 'creator',
              text: `✅ گروه «${input.title}» با شناسه ${input.rubikaChatId} متصل شد.`,
              isBot: true,
              timestamp: now.toISOString(),
            },
          ],
        };

    this.state.groups[id] = group;
    this.state.activeGroupId = id;
    this.addLog('GROUP_ADD', 'info', `گروه «${group.title}» (${group.rubikaChatId}) ذخیره شد.`);
    this.saveState();
    return group;
  }

  public addMemberToGroup(groupId: string, name: string, userId: string, role: UserRole = 'member'): GroupState | null {
    const grp = this.state.groups[groupId];
    if (!grp) return null;
    const existingIdx = grp.members.findIndex((m) => m.userId === userId);
    const member: GroupMember = {
      userId: userId.trim(),
      name: name.trim(),
      role,
      joinedAt: new Date().toISOString(),
    };
    if (existingIdx >= 0) {
      grp.members[existingIdx] = member;
    } else {
      grp.members.push(member);
    }
    this.saveState();
    return grp;
  }

  public async callRubikaApi(method: string, payload: Record<string, unknown> = {}): Promise<{
    ok: boolean;
    statusCode?: number;
    data?: Record<string, unknown>;
    error?: string;
  }> {
    const url = `https://botapi.rubika.ir/v3/${encodeURIComponent(this.state.token)}/${method}`;
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'ParyaRubikaMusicBot/1.0',
        },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(8000),
      });
      const text = await response.text();
      let parsed: Record<string, unknown> = {};
      try {
        parsed = JSON.parse(text) as Record<string, unknown>;
      } catch {
        parsed = {raw: text};
      }
      if (!response.ok) {
        const errText = `HTTP ${response.status}: ${text.slice(0, 180)}`;
        this.addLog(method, 'error', errText);
        return {ok: false, statusCode: response.status, data: parsed, error: errText};
      }
      this.addLog(method, 'ok', `پاسخ دریافت شد (${response.status})`);
      return {ok: true, statusCode: response.status, data: parsed};
    } catch (err) {
      const message = err instanceof Error ? err.message : 'خطا در برقراری ارتباط با سرور روبیکا';
      this.addLog(method, 'error', message);
      return {ok: false, error: message};
    }
  }

  public async verifyToken(): Promise<BotConfigState['lastVerifyResult']> {
    const res = await this.callRubikaApi('getMe', {});
    if (res.ok && res.data && (res.data.status === 'OK' || res.data.data || res.data.bot)) {
      this.state.lastVerifyResult = {
        verified: true,
        checkedAt: new Date().toISOString(),
        botInfo: (res.data.data as Record<string, unknown>) || res.data,
      };
    } else {
      this.state.lastVerifyResult = {
        verified: false,
        checkedAt: new Date().toISOString(),
        error: res.error || JSON.stringify(res.data || {}),
      };
    }
    this.saveState();
    return this.state.lastVerifyResult;
  }

  public startPolling(): BotConfigState {
    if (this.pollingTimer) {
      clearInterval(this.pollingTimer);
      this.pollingTimer = null;
    }
    this.state.pollingActive = true;
    this.addLog('POLLING_START', 'info', 'حلقه دریافت پیام‌های زنده روبیکا (getUpdates) فعال شد.');
    this.saveState();

    const pollOnce = async () => {
      if (!this.state.pollingActive || this.isPollingBusy) return;
      this.isPollingBusy = true;
      try {
        const payload: Record<string, unknown> = {limit: 50};
        if (this.pollingOffset) {
          payload.offset_id = this.pollingOffset;
        }
        const res = await this.callRubikaApi('getUpdates', payload);
        if (res.ok && res.data) {
          const dataObj = (res.data.data as Record<string, unknown>) || res.data;
          const updates = (dataObj.updates as Array<Record<string, unknown>>) || [];
          for (const upd of updates) {
            if (typeof upd.next_offset_id === 'string') {
              this.pollingOffset = upd.next_offset_id;
            }
            const newMsg = upd.new_message as Record<string, unknown> | undefined;
            if (newMsg && typeof newMsg.text === 'string') {
              await this.handleIncomingRubikaUpdate(newMsg);
            }
          }
        }
      } finally {
        this.isPollingBusy = false;
      }
    };

    void pollOnce();
    this.pollingTimer = setInterval(() => {
      void pollOnce();
    }, 3000);

    return this.state;
  }

  public stopPolling(): BotConfigState {
    if (this.pollingTimer) {
      clearInterval(this.pollingTimer);
      this.pollingTimer = null;
    }
    this.state.pollingActive = false;
    this.addLog('POLLING_STOP', 'info', 'دریافت پیام‌های روبیکا متوقف شد.');
    this.saveState();
    return this.state;
  }

  public async handleIncomingRubikaUpdate(rawMsg: Record<string, unknown>): Promise<void> {
    const chatId = String(rawMsg.chat_id || '');
    const senderId = String(rawMsg.sender_id || 'rubika_user');
    const text = String(rawMsg.text || '').trim();
    const messageId = String(rawMsg.message_id || '');
    if (!chatId || !text) return;

    // Find matching group by rubikaChatId or create one automatically
    let group = Object.values(this.state.groups).find((g) => g.rubikaChatId === chatId);
    if (!group) {
      group = this.addOrUpdateGroup({
        title: `گروه روبیکا (${chatId.slice(0, 8)})`,
        rubikaChatId: chatId,
      });
    }

    const replyToObj = rawMsg.reply_to_message as Record<string, unknown> | undefined;
    const replyFile = replyToObj?.file_inline as Record<string, unknown> | undefined;

    await this.executeCommand({
      groupId: group.groupId,
      senderId,
      senderName: String(rawMsg.sender_name || `کاربر ${senderId.slice(0, 6)}`),
      text,
      replyToMessageId: replyToObj ? String(replyToObj.message_id || '') : undefined,
      replyToSenderId: replyToObj ? String(replyToObj.sender_id || '') : undefined,
      replyToAudioUrl: replyFile?.file_url ? String(replyFile.file_url) : undefined,
      sendToRubika: true,
      rubikaReplyMessageId: messageId,
    });
  }

  private getMemberRole(group: GroupState, userId: string): UserRole {
    if (userId === this.state.creatorId) return 'creator';
    if (group.ownerId === userId) return 'owner';
    const member = group.members.find((m) => m.userId === userId);
    return member?.role || 'member';
  }

  private getRoleTitleFa(role: UserRole): string {
    switch (role) {
      case 'creator':
        return `سازنده ربات (${this.state.creatorName})`;
      case 'owner':
        return 'مالک گروه';
      case 'admin':
        return 'ادمین گروه';
      case 'vip':
        return 'کاربر ویژه';
      default:
        return 'کاربر عادی';
    }
  }

  private formatTrackInfo(track: Track): string {
    return `${track.title} — ${track.artist}`;
  }

  private pushHistory(group: GroupState, track: Track | null): void {
    if (!track) return;
    group.history = [...group.history.filter((t) => t.id !== track.id), track].slice(-30);
  }

  private recordTrackPlay(group: GroupState, track: Track | null): void {
    if (!track) return;
    const evt: PlaybackAnalyticsEvent = {
      id: `play_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      trackId: track.id,
      title: track.title,
      artist: track.artist,
      mood: track.mood,
      source: track.source,
      requestedBy: track.requestedBy || 'کاربر',
      timestamp: new Date().toISOString(),
    };
    group.playbackEvents = [...(group.playbackEvents || []), evt].slice(-500);
  }

  public async executeCommand(params: {
    groupId: string;
    senderId: string;
    senderName?: string;
    text: string;
    replyToMessageId?: string;
    replyToSenderId?: string;
    replyToAudioUrl?: string;
    replyToTitle?: string;
    sendToRubika?: boolean;
    rubikaReplyMessageId?: string;
  }): Promise<{
    group: GroupState;
    userMessage: ChatMessage;
    botMessage: ChatMessage | null;
    searchResults?: Track[];
  }> {
    const group = this.state.groups[params.groupId] || this.state.groups[this.state.activeGroupId];
    const senderRole = this.getMemberRole(group, params.senderId);
    const memberRecord = group.members.find((m) => m.userId === params.senderId);
    const senderName = params.senderName || memberRecord?.name || `کاربر ${params.senderId}`;
    const trimmed = params.text.trim();
    const nowIso = new Date().toISOString();

    let replyMsgObj: ChatMessage | undefined;
    if (params.replyToMessageId) {
      replyMsgObj = group.messages.find((m) => m.id === params.replyToMessageId);
    }

    const userMessage: ChatMessage = {
      id: `u_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      groupId: group.groupId,
      senderId: params.senderId,
      senderName,
      senderRole,
      text: trimmed,
      isBot: false,
      replyToMessageId: params.replyToMessageId,
      replyPreview: replyMsgObj ? `${replyMsgObj.senderName}: ${replyMsgObj.text.slice(0, 48)}` : undefined,
      timestamp: nowIso,
    };
    group.messages = [...group.messages, userMessage].slice(-120);

    let replyText = '';
    let botAudioAttachment: ChatMessage['audioAttachment'] | undefined;
    let searchResults: Track[] | undefined;

    const replyTargetSenderId = params.replyToSenderId || replyMsgObj?.senderId;
    const replyTargetAudioUrl =
      params.replyToAudioUrl ||
      replyMsgObj?.audioAttachment?.url ||
      (replyMsgObj?.text.match(/https?:\/\/\S+/i)?.[0] ?? undefined);
    const replyTargetTitle =
      params.replyToTitle || replyMsgObj?.audioAttachment?.title || 'فایل صوتی ریپلای شده';

    const hasMusicAccess =
      group.publicAccess === 'open' || ['creator', 'owner', 'admin', 'vip'].includes(senderRole);

    // 1. Help
    if (/^(راهنما|راهنمای ربات|راهنمای ربات موزیکال|\/help|\/start)$/i.test(trimmed)) {
      replyText = [
        `🎵 راهنمای ربات موزیکال پیشرفته روبیکا`,
        `👑 سازنده: ${this.state.creatorName}`,
        ``,
        `🔍 جستجوی آهنگ: آهنگ {نام موسیقی} (مثال: آهنگ لری)`,
        `🔗 پخش از لینک مستقیم: پخش ویسکال {لینک دانلود}`,
        `⏹ توقف و ذخیره: قطع ویسکال / توقف آهنگ / خروج / توقف`,
        `▶️ ادامه پخش: ادامه آهنگ`,
        `🔄 پخش با ریپلای: پخش ریپلای`,
        `🎲 پخش تصادفی: پخش رندوم`,
        `📋 صف و تاریخچه: بعدی | قبلی | صف | لیست پخش | اضافه به صف | پاک کردن صف | حذف از صف {شماره} | تاریخچه آهنگها`,
        `⚡ پخش فوری: پخش فوری (با ریپلای یا لینک)`,
        `🔊 کنترل صدا: تنظیم صدا {0-100} | بیصدا | باصدا`,
        `👑 مدیریت گروه: مالک گروه | ویژه | حذف ویژه | تنظیم مالک | دسترسی عموم باز | دسترسی عموم قفل باشد | مقام`,
        `📞 کال و اشتراک: ساخت کال | وضعیت`,
      ].join('\n');
    }
    // 2. Role check
    else if (trimmed === 'مقام') {
      replyText = `🔵 مقام شما در این گروه: ${this.getRoleTitleFa(senderRole)}`;
    }
    // 3. Group Owner display
    else if (trimmed === 'مالک گروه') {
      replyText = `🟢 مالک فعلی گروه:\n👤 نام: ${group.ownerName}\n🆔 شناسه: ${group.ownerId}\n👑 سازنده ربات: ${this.state.creatorName}`;
    }
    // 4. Subscription status
    else if (trimmed === 'وضعیت') {
      const expDate = new Date(group.subscription.expiresAt);
      const buyDate = new Date(group.subscription.purchasedAt);
      const daysLeft = Math.max(0, Math.ceil((expDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24)));
      const accessLabel =
        group.publicAccess === 'open' ? 'باز (همه اعضا مجاز هستند)' : 'قفل (فقط کاربران ویژه و ادمین‌ها)';
      replyText = [
        `🔐 وضعیت اشتراک و دسترسی گروه «${group.title}»`,
        `📅 تاریخ خرید: ${buyDate.toLocaleDateString('fa-IR')}`,
        `⏳ تاریخ انقضا: ${expDate.toLocaleDateString('fa-IR')}`,
        `📆 روزهای باقیمانده: ${daysLeft} روز`,
        `🔓 وضعیت دسترسی عمومی: ${accessLabel}`,
        `📞 وضعیت ویسکال: ${group.voiceCallActive ? 'فعال و متصل' : 'غیرفعال'}`,
        `👑 سازنده: ${this.state.creatorName}`,
      ].join('\n');
    }
    // 5. Set Owner (Creator ONLY)
    else if (trimmed === 'تنظیم مالک') {
      if (senderRole !== 'creator') {
        replyText = `⛔ فقط سازنده ربات (${this.state.creatorName}) مجاز به تعیین مالک گروه است.`;
      } else if (!replyTargetSenderId) {
        replyText = '⚠ لطفاً روی پیام کاربر مورد نظر ریپلای کنید و ارسال کنید: تنظیم مالک';
      } else {
        const targetMember = group.members.find((m) => m.userId === replyTargetSenderId);
        const targetName = targetMember?.name || replyMsgObj?.senderName || replyTargetSenderId;
        group.ownerId = replyTargetSenderId;
        group.ownerName = targetName;
        if (targetMember) {
          targetMember.role = 'owner';
        } else {
          group.members.push({
            userId: replyTargetSenderId,
            name: targetName,
            role: 'owner',
            joinedAt: nowIso,
          });
        }
        replyText = `👑 کاربر «${targetName}» (${replyTargetSenderId}) به عنوان مالک گروه تنظیم شد.`;
      }
    }
    // 6. Add VIP (Creator / Owner / Admin)
    else if (trimmed === 'ویژه') {
      if (!['creator', 'owner', 'admin'].includes(senderRole)) {
        replyText = '⛔ فقط مالک گروه، ادمین یا سازنده ربات می‌تواند کاربر را ویژه کند.';
      } else if (!replyTargetSenderId) {
        replyText = '⚠ لطفاً روی پیام کاربر مورد نظر ریپلای کنید و بنویسید: ویژه';
      } else {
        const targetMember = group.members.find((m) => m.userId === replyTargetSenderId);
        const targetName = targetMember?.name || replyMsgObj?.senderName || replyTargetSenderId;
        if (targetMember) {
          if (targetMember.role === 'member') targetMember.role = 'vip';
        } else {
          group.members.push({
            userId: replyTargetSenderId,
            name: targetName,
            role: 'vip',
            joinedAt: nowIso,
          });
        }
        replyText = `⭐ کاربر «${targetName}» با موفقیت ویژه شد و دسترسی به ربات را دریافت کرد.`;
      }
    }
    // 7. Remove VIP (Owner or Creator ONLY)
    else if (trimmed === 'حذف ویژه') {
      if (!['creator', 'owner'].includes(senderRole)) {
        replyText = '⛔ فقط مالک گروه یا سازنده ربات می‌تواند وضعیت ویژه کاربر را حذف کند.';
      } else if (!replyTargetSenderId) {
        replyText = '⚠ لطفاً روی پیام کاربر مورد نظر ریپلای کنید و بنویسید: حذف ویژه';
      } else {
        const targetMember = group.members.find((m) => m.userId === replyTargetSenderId);
        if (targetMember && targetMember.role === 'vip') {
          targetMember.role = 'member';
          replyText = `🗑 دسترسی ویژه کاربر «${targetMember.name}» حذف شد.`;
        } else {
          replyText = 'ℹ این کاربر در لیست کاربران ویژه نیست.';
        }
      }
    }
    // 8. Public access open / locked
    else if (trimmed === 'دسترسی عموم باز') {
      if (!['creator', 'owner', 'admin'].includes(senderRole)) {
        replyText = '⛔ فقط مالک، ادمین یا سازنده ربات می‌تواند دسترسی عمومی را تغییر دهد.';
      } else {
        group.publicAccess = 'open';
        replyText = '🔓 دسترسی عمومی باز شد. از این پس همه اعضای گروه می‌توانند از ربات استفاده کنند.';
      }
    } else if (trimmed === 'دسترسی عموم قفل باشد' || trimmed === 'دسترسی عموم قفل') {
      if (!['creator', 'owner', 'admin'].includes(senderRole)) {
        replyText = '⛔ فقط مالک، ادمین یا سازنده ربات می‌تواند دسترسی عمومی را تغییر دهد.';
      } else {
        group.publicAccess = 'locked';
        replyText = '🔒 دسترسی عمومی قفل شد. فقط کاربران ویژه، ادمین‌ها و مالک گروه دسترسی دارند.';
      }
    }
    // 9. Music / Voice Call commands permission check
    else if (!hasMusicAccess) {
      replyText = '🔒 دسترسی عمومی گروه قفل است. فقط کاربران ویژه و ادمین‌ها می‌توانند از دستورات موزیک استفاده کنند.';
    }
    // 10. Create voice call
    else if (trimmed === 'ساخت کال') {
      group.voiceCallActive = true;
      group.voiceCallId = group.voiceCallId || `vc_${Date.now()}`;
      group.voiceCallStartedAt = group.voiceCallStartedAt || nowIso;
      replyText = `📞 ویس‌چت (کال) در گروه «${group.title}» ایجاد و فعال شد.\nربات آماده پخش موزیک در کال است.`;
    }
    // 10b. Auto-shutdown timer commands
    else if (/^(تنظیم خاموشی|خاموشی خودکار|تایمر قطع)\s+[0-9۰-۹]{1,2}:[0-9۰-۹]{2}$/.test(trimmed)) {
      if (!['creator', 'owner', 'admin'].includes(senderRole)) {
        replyText = '⛔ فقط مالک، ادمین یا سازنده ربات می‌تواند تایمر خاموشی خودکار تنظیم کند.';
      } else {
        const timePart = this.normalizeDigits(trimmed.split(/\s+/).pop() || '');
        const padded = timePart
          .split(':')
          .map((p) => p.padStart(2, '0'))
          .join(':');
        const tzOffset = group.autoShutdown?.timezoneOffsetMinutes ?? -210;
        const nextIso = this.computeNextTriggerIso(padded, tzOffset);
        if (!nextIso) {
          replyText = '⚠ فرمت ساعت معتبر نیست. مثال صحیح: تنظیم خاموشی 23:30';
        } else {
          group.autoShutdown = {
            enabled: true,
            targetTime: padded,
            timezoneOffsetMinutes: tzOffset,
            stopPollingAlso: group.autoShutdown?.stopPollingAlso ?? false,
            nextTriggerIso: nextIso,
            lastTriggeredAt: group.autoShutdown?.lastTriggeredAt || null,
          };
          replyText = `⏰ تایمر قطع خودکار ویسکال برای ساعت ${padded} تنظیم شد.`;
        }
      }
    } else if (['لغو خاموشی', 'حذف تایمر', 'لغو تایمر'].includes(trimmed)) {
      if (!['creator', 'owner', 'admin'].includes(senderRole)) {
        replyText = '⛔ فقط مالک، ادمین یا سازنده ربات می‌تواند تایمر را لغو کند.';
      } else {
        if (group.autoShutdown) {
          group.autoShutdown.enabled = false;
          group.autoShutdown.nextTriggerIso = null;
        }
        replyText = '⏰ تایمر خاموشی خودکار ویسکال لغو شد.';
      }
    } else if (trimmed === 'وضعیت تایمر' || trimmed === 'زمان خاموشی') {
      if (group.autoShutdown?.enabled && group.autoShutdown.nextTriggerIso) {
        const diffMin = Math.max(
          0,
          Math.round((new Date(group.autoShutdown.nextTriggerIso).getTime() - Date.now()) / 60000),
        );
        replyText = `⏰ خاموشی خودکار ویسکال روی ساعت ${group.autoShutdown.targetTime} فعال است (${diffMin} دقیقه باقیمانده).`;
      } else {
        replyText = '⏰ هیچ تایمر خاموشی خودکاری برای این گروه فعال نیست.';
      }
    }
    // 11. Mute / Unmute
    else if (trimmed === 'بیصدا') {
      group.isMuted = true;
      replyText = '🟣 ربات در کال بی‌صدا شد (پخش آهنگ در پس‌زمینه ادامه دارد).';
    } else if (trimmed === 'باصدا') {
      group.isMuted = false;
      replyText = '🟠 ربات از حالت بی‌صدا خارج شد و آهنگ در حال پخش است ✅';
    }
    // 12. Set Volume
    else if (/^تنظیم صدا\s+\d{1,3}$/.test(trimmed)) {
      const volNum = Number(trimmed.replace('تنظیم صدا', '').trim());
      const clamped = Math.max(0, Math.min(100, volNum));
      group.volume = clamped;
      replyText = `🔊 صدای پخش ربات روی ${clamped} درصد تنظیم شد.`;
    }
    // 13. Stop & Save paused track
    else if (['قطع ویسکال', 'توقف آهنگ', 'خروج', 'توقف'].includes(trimmed)) {
      if (group.currentTrack) {
        group.pausedTrack = group.currentTrack;
        group.currentTrack = null;
        group.isPlaying = false;
        if (trimmed === 'خروج' || trimmed === 'قطع ویسکال') {
          group.voiceCallActive = false;
        }
        replyText = `⏹ پخش آهنگ «${group.pausedTrack.title}» متوقف و ذخیره شد. برای ادامه بنویسید: ادامه آهنگ`;
      } else {
        group.isPlaying = false;
        if (trimmed === 'خروج' || trimmed === 'قطع ویسکال') {
          group.voiceCallActive = false;
        }
        replyText = '⏹ پخش و ویسکال متوقف شد.';
      }
    }
    // 14. Resume paused track
    else if (trimmed === 'ادامه آهنگ') {
      if (group.pausedTrack) {
        group.currentTrack = group.pausedTrack;
        group.pausedTrack = null;
        group.isPlaying = true;
        group.voiceCallActive = true;
        this.recordTrackPlay(group, group.currentTrack);
        botAudioAttachment = {
          title: group.currentTrack.title,
          artist: group.currentTrack.artist,
          url: group.currentTrack.streamUrl,
          durationSec: group.currentTrack.durationSec,
        };
        replyText = `▶️ ادامه پخش آهنگ «${group.currentTrack.title}» در ویسکال.`;
      } else {
        replyText = '⚠ آهنگ متوقف‌شده‌ای برای ادامه وجود ندارد.';
      }
    }
    // 15. Queue display
    else if (trimmed === 'صف' || trimmed === 'لیست پخش') {
      if (group.queue.length === 0) {
        replyText = '📋 صف پخش در حال حاضر خالی است.';
      } else {
        const list = group.queue.map((t, idx) => `${idx + 1}. ${this.formatTrackInfo(t)}`).join('\n');
        replyText = `📋 لیست صف پخش (${group.queue.length} آهنگ):\n${list}`;
      }
    }
    // 16. Clear queue
    else if (trimmed === 'پاک کردن صف') {
      group.queue = [];
      replyText = '🗑 کل صف پخش خالی شد.';
    }
    // 17. Delete from queue by index
    else if (/^حذف از صف\s+\d+$/.test(trimmed)) {
      const idx = Number(trimmed.replace('حذف از صف', '').trim()) - 1;
      if (idx >= 0 && idx < group.queue.length) {
        const [removed] = group.queue.splice(idx, 1);
        replyText = `🗑 آهنگ «${removed.title}» از ردیف ${idx + 1} صف حذف شد.`;
      } else {
        replyText = `⚠ شماره ${idx + 1} در صف وجود ندارد.`;
      }
    }
    // 18. History (last 5)
    else if (trimmed === 'تاریخچه آهنگها' || trimmed === 'تاریخچه آهنگ‌ها') {
      const last5 = group.history.slice(-5).reverse();
      if (last5.length === 0) {
        replyText = '📜 هنوز آهنگی در تاریخچه ثبت نشده است.';
      } else {
        const lines = last5.map((t, idx) => `${idx + 1}. ${this.formatTrackInfo(t)}`).join('\n');
        replyText = `📜 ۵ آهنگ آخر پخش‌شده:\n${lines}`;
      }
    }
    // 19. Next track
    else if (trimmed === 'بعدی') {
      if (group.queue.length === 0) {
        replyText = '⚠ آهنگ بعدی در صف وجود ندارد.';
      } else {
        if (group.currentTrack) this.pushHistory(group, group.currentTrack);
        const nextTrack = group.queue.shift()!;
        group.currentTrack = nextTrack;
        group.pausedTrack = null;
        group.isPlaying = true;
        group.voiceCallActive = true;
        this.recordTrackPlay(group, nextTrack);
        botAudioAttachment = {
          title: nextTrack.title,
          artist: nextTrack.artist,
          url: nextTrack.streamUrl,
          durationSec: nextTrack.durationSec,
        };
        replyText = `⏭ پخش آهنگ بعدی از صف:\n🎶 ${this.formatTrackInfo(nextTrack)}`;
      }
    }
    // 20. Previous track
    else if (trimmed === 'قبلی') {
      if (group.history.length === 0) {
        replyText = '⚠ آهنگی در تاریخچه برای بازگشت وجود ندارد.';
      } else {
        const prevTrack = group.history.pop()!;
        if (group.currentTrack) {
          group.queue.unshift(group.currentTrack);
        }
        group.currentTrack = prevTrack;
        group.pausedTrack = null;
        group.isPlaying = true;
        group.voiceCallActive = true;
        this.recordTrackPlay(group, prevTrack);
        botAudioAttachment = {
          title: prevTrack.title,
          artist: prevTrack.artist,
          url: prevTrack.streamUrl,
          durationSec: prevTrack.durationSec,
        };
        replyText = `⏮ بازگشت به آهنگ قبلی:\n🎶 ${this.formatTrackInfo(prevTrack)}`;
      }
    }
    // 20b. Archive stats command
    else if (trimmed === 'آمار آرشیو' || trimmed === 'تعداد آهنگها' || trimmed === 'تعداد آهنگ‌ها') {
      const stats = musicCatalog.getStats();
      replyText = [
        `📚 آمار آرشیو موسیقی ربات:`,
        `🎵 کل آهنگ‌های آماده پخش: ${stats.total} آهنگ`,
        `🎉 آهنگ‌های شاد: ${stats.countsByMood['شاد'] || 0}`,
        `💔 آهنگ‌های غمگین: ${stats.countsByMood['غمگین'] || 0}`,
        `🏔 محلی و لری: ${stats.countsByMood['محلی و لری'] || 0}`,
        `🎼 سنتی و اصیل: ${stats.countsByMood['سنتی'] || 0}`,
        `🎤 پاپ و نوستالژی: ${(stats.countsByMood['پاپ'] || 0) + (stats.countsByMood['نوستالژی'] || 0)}`,
      ].join('\n');
    }
    // 21. Random playback (including mood variants: پخش رندوم شاد / پخش رندوم غمگین)
    else if (
      trimmed === 'پخش رندوم' ||
      trimmed === 'پخش رندوم شاد' ||
      trimmed === 'پخش شاد' ||
      trimmed === 'آهنگ شاد' ||
      trimmed === 'پخش رندوم غمگین' ||
      trimmed === 'پخش غمگین' ||
      trimmed === 'آهنگ غمگین'
    ) {
      const requestedMood: MusicMood | undefined = trimmed.includes('شاد')
        ? 'شاد'
        : trimmed.includes('غمگین')
          ? 'غمگین'
          : undefined;

      let chosen: Track | undefined;
      if (!requestedMood && group.queue.length > 0) {
        const randIdx = Math.floor(Math.random() * group.queue.length);
        [chosen] = group.queue.splice(randIdx, 1);
      } else {
        const fromCatalog = musicCatalog.pickRandom(requestedMood, 1, senderName);
        if (fromCatalog.length > 0) {
          chosen = fromCatalog[0];
        } else if (group.history.length > 0 && !requestedMood) {
          chosen = group.history[Math.floor(Math.random() * group.history.length)];
        } else {
          const fallbackQuery =
            requestedMood === 'شاد'
              ? 'بهنام بانی شاد'
              : requestedMood === 'غمگین'
                ? 'محسن چاوشی غمگین'
                : 'آهنگ شاد ایرانی';
          const results = await searchMusicReal(fallbackQuery, senderName);
          if (results.length > 0) {
            chosen = results[Math.floor(Math.random() * results.length)];
          }
        }
      }
      if (!chosen) {
        replyText = '⚠ آهنگی برای پخش تصادفی یافت نشد.';
      } else {
        if (group.currentTrack) this.pushHistory(group, group.currentTrack);
        group.currentTrack = chosen;
        group.pausedTrack = null;
        group.isPlaying = true;
        group.voiceCallActive = true;
        this.recordTrackPlay(group, chosen);
        botAudioAttachment = {
          title: chosen.title,
          artist: chosen.artist,
          url: chosen.streamUrl,
          durationSec: chosen.durationSec,
        };
        const moodLabel = requestedMood ? ` (${requestedMood})` : '';
        replyText = `🎲 پخش تصادفی${moodLabel} در ویسکال:\n🎶 ${this.formatTrackInfo(chosen)}`;
      }
    }
    // 22. Direct link / Reply play / Instant play / Add to queue
    else if (
      trimmed.startsWith('پخش ویسکال ') ||
      trimmed === 'پخش ریپلای' ||
      trimmed === 'پخش فوری' ||
      trimmed.startsWith('پخش فوری ') ||
      trimmed === 'اضافه به صف' ||
      trimmed.startsWith('اضافه به صف ')
    ) {
      const inlineUrl = trimmed.match(/https?:\/\/\S+/i)?.[0];
      const rawUrl = inlineUrl || replyTargetAudioUrl;
      if (!rawUrl) {
        replyText = '⚠ لطفاً لینک مستقیم فایل صوتی را وارد کنید یا روی یک پیام حاوی فایل صوتی / لینک ریپلای کنید.';
      } else {
        const track = buildTrackFromDirectUrl(
          rawUrl,
          senderName,
          inlineUrl ? undefined : replyTargetTitle,
          trimmed === 'پخش ریپلای' ? 'reply' : 'direct',
        );
        if (!track) {
          replyText = '❌ لینک وارد شده معتبر نیست.';
        } else if (trimmed.startsWith('اضافه به صف')) {
          group.queue.push(track);
          replyText = `➕ آهنگ «${track.title}» به انتهای صف اضافه شد (موقعیت: ${group.queue.length}).`;
        } else {
          if (group.currentTrack) this.pushHistory(group, group.currentTrack);
          group.currentTrack = track;
          group.pausedTrack = null;
          group.isPlaying = true;
          group.voiceCallActive = true;
          this.recordTrackPlay(group, track);
          botAudioAttachment = {
            title: track.title,
            artist: track.artist,
            url: track.streamUrl,
            durationSec: track.durationSec,
          };
          const prefix = trimmed.startsWith('پخش فوری')
            ? '⚡ پخش فوری (آهنگ قبلی قطع شد)'
            : trimmed === 'پخش ریپلای'
              ? '🔄 پخش از روی پیام ریپلای شده'
              : '🔗 پخش مستقیم در ویسکال';
          replyText = `${prefix}:\n🎶 ${track.title}`;
        }
      }
    }
    // 23. Music search: آهنگ {نام موسیقی}
    else if (trimmed.startsWith('آهنگ ')) {
      const query = trimmed.slice('آهنگ '.length).trim();
      if (!query) {
        replyText = '⚠ لطفاً نام آهنگ را وارد کنید. مثال: آهنگ لری';
      } else {
        const results = await searchMusicReal(query, senderName);
        searchResults = results;
        if (results.length === 0) {
          replyText = `❌ نتیجه‌ای برای «${query}» پیدا نشد. عبارت دیگری را امتحان کنید یا لینک مستقیم بفرستید.`;
        } else {
          const chosen = results[0];
          if (group.currentTrack) this.pushHistory(group, group.currentTrack);
          group.currentTrack = chosen;
          group.pausedTrack = null;
          group.isPlaying = true;
          group.voiceCallActive = true;
          this.recordTrackPlay(group, chosen);
          botAudioAttachment = {
            title: chosen.title,
            artist: chosen.artist,
            url: chosen.streamUrl,
            durationSec: chosen.durationSec,
          };
          replyText = [
            `🔍 نتیجه جستجو برای «${query}» (${results.length} مورد یافت شد):`,
            `🎵 در حال پخش در ویسکال: ${chosen.title} — ${chosen.artist}`,
            `🔊 صدا: ${group.volume}% ${group.isMuted ? '(بیصدا)' : '(باصدا)'}`,
          ].join('\n');
        }
      }
    } else {
      // Unknown text — no bot spam unless it looks like a command
      this.saveState();
      return {group, userMessage, botMessage: null};
    }

    let deliveredToRubika = false;
    let rubikaMessageId: string | undefined;

    if (params.sendToRubika && group.rubikaChatId) {
      const sendRes = await this.callRubikaApi('sendMessage', {
        chat_id: group.rubikaChatId,
        text: replyText,
        ...(params.rubikaReplyMessageId ? {reply_to_message_id: params.rubikaReplyMessageId} : {}),
      });
      deliveredToRubika = sendRes.ok;
      if (sendRes.ok && sendRes.data) {
        const d = (sendRes.data.data as Record<string, unknown>) || sendRes.data;
        if (d.message_id) rubikaMessageId = String(d.message_id);
      }
    }

    const botMessage: ChatMessage = {
      id: `b_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      groupId: group.groupId,
      senderId: 'bot_rubika',
      senderName: this.state.botName,
      senderRole: 'creator',
      text: replyText,
      isBot: true,
      replyToMessageId: userMessage.id,
      audioAttachment: botAudioAttachment,
      deliveredToRubika,
      rubikaMessageId,
      timestamp: new Date().toISOString(),
    };
    group.messages = [...group.messages, botMessage].slice(-120);
    this.saveState();

    return {group, userMessage, botMessage, searchResults};
  }

  public playSpecificTrack(groupId: string, track: Track, mode: 'play_now' | 'queue'): GroupState | null {
    const group = this.state.groups[groupId];
    if (!group) return null;
    if (mode === 'queue') {
      group.queue.push(track);
      const queuedMsg: ChatMessage = {
        id: `b_${Date.now()}`,
        groupId: group.groupId,
        senderId: 'bot_rubika',
        senderName: this.state.botName,
        senderRole: 'creator',
        text: `➕ آهنگ «${track.title}» به صف پخش اضافه شد (شماره ${group.queue.length}).`,
        isBot: true,
        timestamp: new Date().toISOString(),
      };
      group.messages = [...group.messages, queuedMsg].slice(-120);
    } else {
      if (group.currentTrack) this.pushHistory(group, group.currentTrack);
      group.currentTrack = track;
      group.pausedTrack = null;
      group.isPlaying = true;
      group.voiceCallActive = true;
      this.recordTrackPlay(group, track);
      const playMsg: ChatMessage = {
        id: `b_${Date.now()}`,
        groupId: group.groupId,
        senderId: 'bot_rubika',
        senderName: this.state.botName,
        senderRole: 'creator',
        text: `🎵 در حال پخش در ویسکال:\n🎶 ${track.title} — ${track.artist}`,
        isBot: true,
        audioAttachment: {
          title: track.title,
          artist: track.artist,
          url: track.streamUrl,
          durationSec: track.durationSec,
        },
        timestamp: new Date().toISOString(),
      };
      group.messages = [...group.messages, playMsg].slice(-120);
    }
    this.saveState();
    return group;
  }

  public enqueueBulkTracks(groupId: string, tracks: Track[], moodLabel?: string): GroupState | null {
    const group = this.state.groups[groupId];
    if (!group || tracks.length === 0) return null;
    group.queue.push(...tracks);
    if (!group.currentTrack) {
      const first = group.queue.shift()!;
      group.currentTrack = first;
      group.isPlaying = true;
      group.voiceCallActive = true;
      this.recordTrackPlay(group, first);
    }
    const noticeMsg: ChatMessage = {
      id: `b_${Date.now()}`,
      groupId: group.groupId,
      senderId: 'bot_rubika',
      senderName: this.state.botName,
      senderRole: 'creator',
      text: `🎶 ${tracks.length} آهنگ ${moodLabel ? `(${moodLabel}) ` : ''}به صف پخش ویسکال اضافه شد.`,
      isBot: true,
      timestamp: new Date().toISOString(),
    };
    group.messages = [...group.messages, noticeMsg].slice(-120);
    this.saveState();
    return group;
  }

  public applySmartPlaylist(
    groupId: string,
    input: {
      name: string;
      moods: MusicMood[];
      tracks: Track[];
      balanceMode: 'interleaved' | 'shuffled';
      startMode: 'replace_and_play' | 'append_queue';
      savePreset?: boolean;
    },
  ): GroupState | null {
    const group = this.state.groups[groupId];
    if (!group || input.tracks.length === 0) return null;

    if (input.startMode === 'replace_and_play') {
      if (group.currentTrack) {
        this.pushHistory(group, group.currentTrack);
      }
      const [first, ...rest] = input.tracks;
      group.currentTrack = first;
      group.pausedTrack = null;
      group.queue = rest;
      group.isPlaying = true;
      group.voiceCallActive = true;
      this.recordTrackPlay(group, first);
    } else {
      group.queue.push(...input.tracks);
      if (!group.currentTrack) {
        const first = group.queue.shift()!;
        group.currentTrack = first;
        group.isPlaying = true;
        group.voiceCallActive = true;
        this.recordTrackPlay(group, first);
      }
    }

    if (input.savePreset) {
      const preset: SmartPlaylistPreset = {
        id: `pl_${Date.now()}`,
        name: input.name,
        moods: input.moods,
        trackCount: input.tracks.length,
        balanceMode: input.balanceMode,
        createdAt: new Date().toISOString(),
      };
      group.savedPlaylists = [preset, ...(group.savedPlaylists || [])].slice(0, 12);
    }

    const moodStr = input.moods.join(' + ');
    const actionLabel =
      input.startMode === 'replace_and_play'
        ? 'پخش متوالی در ویس‌چت آغاز شد'
        : 'به صف پخش اضافه شد';

    const msg: ChatMessage = {
      id: `b_mix_${Date.now()}`,
      groupId: group.groupId,
      senderId: 'bot_rubika',
      senderName: this.state.botName,
      senderRole: 'creator',
      text: `🎛 پلی‌لیست هوشمند «${input.name}» (${input.tracks.length} آهنگ از سبک‌های: ${moodStr}) ایجاد و ${actionLabel}.\n🎵 آهنگ اول: ${group.currentTrack?.title || input.tracks[0].title}`,
      isBot: true,
      audioAttachment: {
        title: input.tracks[0].title,
        artist: input.tracks[0].artist,
        url: input.tracks[0].streamUrl,
        durationSec: input.tracks[0].durationSec,
      },
      timestamp: new Date().toISOString(),
    };
    group.messages = [...group.messages, msg].slice(-120);
    this.addLog('SMART_PLAYLIST', 'info', `${group.title}: ${input.name} (${input.tracks.length} tracks)`);
    this.saveState();
    return group;
  }

  public deleteSavedPlaylist(groupId: string, playlistId: string): GroupState | null {
    const group = this.state.groups[groupId];
    if (!group) return null;
    group.savedPlaylists = (group.savedPlaylists || []).filter((p) => p.id !== playlistId);
    this.saveState();
    return group;
  }

  public handleTrackEnded(groupId: string): GroupState | null {
    const group = this.state.groups[groupId];
    if (!group) return null;
    if (group.currentTrack) {
      this.pushHistory(group, group.currentTrack);
    }
    if (group.queue.length > 0) {
      const nextTrack = group.queue.shift()!;
      group.currentTrack = nextTrack;
      group.isPlaying = true;
      this.recordTrackPlay(group, nextTrack);
    } else {
      group.currentTrack = null;
      group.isPlaying = false;
    }
    this.saveState();
    return group;
  }

  public getGroupAnalytics(groupId: string, tzOffsetMinutes?: number): GroupAnalyticsResponse | null {
    const group = this.state.groups[groupId] || this.state.groups[this.state.activeGroupId];
    if (!group) return null;

    const tzOffset =
      typeof tzOffsetMinutes === 'number' && Number.isFinite(tzOffsetMinutes)
        ? tzOffsetMinutes
        : group.autoShutdown?.timezoneOffsetMinutes ?? -210;

    const getLocalHour = (iso: string): number | null => {
      const ms = new Date(iso).getTime();
      if (!Number.isFinite(ms)) return null;
      const localDate = new Date(ms - tzOffset * 60 * 1000);
      return localDate.getUTCHours();
    };

    const hourly: HourlyAnalyticsBucket[] = Array.from({length: 24}, (_, hour) => ({
      hour,
      label: `${String(hour).padStart(2, '0')}:00`,
      tracksPlayed: 0,
      commandsCount: 0,
      totalActivity: 0,
    }));

    // Primary playback log + backfill any pre-existing persisted tracks in history/currentTrack
    const events: PlaybackAnalyticsEvent[] = [...(group.playbackEvents || [])];
    const recordedTrackIds = new Set(events.map((e) => e.trackId));

    const legacyTracks: Track[] = [...group.history];
    if (group.currentTrack) {
      legacyTracks.push(group.currentTrack);
    }
    for (const track of legacyTracks) {
      if (!recordedTrackIds.has(track.id)) {
        recordedTrackIds.add(track.id);
        events.push({
          id: `legacy_${track.id}`,
          trackId: track.id,
          title: track.title,
          artist: track.artist,
          mood: track.mood,
          source: track.source,
          requestedBy: track.requestedBy || 'کاربر',
          timestamp: track.requestedAt || new Date().toISOString(),
        });
      }
    }

    const moodCounts = new Map<string, number>();
    for (const evt of events) {
      const h = getLocalHour(evt.timestamp);
      if (h !== null && hourly[h]) {
        hourly[h].tracksPlayed += 1;
      }
      const moodLabel =
        evt.mood ||
        (evt.source === 'direct'
          ? 'لینک مستقیم'
          : evt.source === 'reply'
            ? 'ریپلای ویسکال'
            : 'جستجوی آنلاین');
      moodCounts.set(moodLabel, (moodCounts.get(moodLabel) || 0) + 1);
    }

    let totalCommands = 0;
    for (const msg of group.messages) {
      if (msg.isBot) continue;
      totalCommands += 1;
      const h = getLocalHour(msg.timestamp);
      if (h !== null && hourly[h]) {
        hourly[h].commandsCount += 1;
      }
    }

    let activeHoursCount = 0;
    let totalActivitySum = 0;
    let peakHour: HourlyAnalyticsBucket | null = null;

    for (const bucket of hourly) {
      bucket.totalActivity = bucket.tracksPlayed + bucket.commandsCount;
      if (bucket.totalActivity > 0) {
        activeHoursCount += 1;
        totalActivitySum += bucket.totalActivity;
        if (
          !peakHour ||
          bucket.totalActivity > peakHour.totalActivity ||
          (bucket.totalActivity === peakHour.totalActivity &&
            bucket.tracksPlayed > peakHour.tracksPlayed)
        ) {
          peakHour = {...bucket};
        }
      }
    }

    const moodBreakdown = Array.from(moodCounts.entries())
      .map(([mood, count]) => ({mood, count}))
      .sort((a, b) => b.count - a.count);

    const recentPlays = [...events]
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, 12);

    return {
      groupId: group.groupId,
      groupTitle: group.title,
      tzOffsetMinutes: tzOffset,
      hourly,
      summary: {
        totalTracksPlayed: events.length,
        totalCommands,
        peakHour,
        activeHoursCount,
        avgPerActiveHour:
          activeHoursCount > 0 ? Number((totalActivitySum / activeHoursCount).toFixed(1)) : 0,
      },
      moodBreakdown,
      recentPlays,
    };
  }
}
