import {useCallback, useEffect, useState} from 'react';
import {
  BarChart3,
  Download,
  FileCode2,
  Headphones,
  Menu,
  MessageSquareText,
  Play,
  Radio,
  ShieldCheck,
  Square,
  X,
} from 'lucide-react';
import {AnalyticsD3View} from './components/AnalyticsD3View';
import {GroupChatConsoleView} from './components/GroupChatConsoleView';
import {GroupsAccessView} from './components/GroupsAccessView';
import {PythonApkExportView} from './components/PythonApkExportView';
import {RubikaConnectionView} from './components/RubikaConnectionView';
import {VoiceCallStudioView} from './components/VoiceCallStudioView';
import {useVoiceAudioEngine} from './hooks/useVoiceAudioEngine';
import {BotConfigState, MusicMood, Track, UserRole} from './types/bot';

type TabKey = 'voice' | 'chat' | 'analytics' | 'groups' | 'rubika' | 'apk';

const NAV_ITEMS: Array<{key: TabKey; label: string; icon: typeof Headphones}> = [
  {key: 'voice', label: 'ویسکال و پخش زنده', icon: Headphones},
  {key: 'chat', label: 'چت گروهی و دستورات', icon: MessageSquareText},
  {key: 'analytics', label: 'آمار و نمودار D3', icon: BarChart3},
  {key: 'groups', label: 'گروه‌ها، مقام و اشتراک', icon: ShieldCheck},
  {key: 'rubika', label: 'اتصال توکن روبیکا', icon: Radio},
  {key: 'apk', label: 'پایتون و ساخت APK گیت‌هاب', icon: FileCode2},
];

export default function App() {
  const [config, setConfig] = useState<BotConfigState | null>(null);
  const [activeTab, setActiveTab] = useState<TabKey>('voice');
  const [isBusy, setIsBusy] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg((prev) => (prev === msg ? null : prev)), 3200);
  }, []);

  const fetchState = useCallback(async () => {
    try {
      const res = await fetch('/api/state');
      if (res.ok) {
        const data = (await res.json()) as BotConfigState;
        setConfig(data);
      }
    } catch {
      // Ignore transient error on initial poll
    }
  }, []);

  useEffect(() => {
    void fetchState();
  }, [fetchState]);

  // Keep state synced when Rubika polling OR any group's auto-shutdown timer is active
  const hasActiveAutoShutdown = Boolean(
    config && Object.values(config.groups).some((g) => g.autoShutdown?.enabled),
  );

  useEffect(() => {
    if (!config?.pollingActive && !hasActiveAutoShutdown) return;
    const timer = setInterval(() => {
      void fetchState();
    }, 3500);
    return () => clearInterval(timer);
  }, [config?.pollingActive, hasActiveAutoShutdown, fetchState]);

  const activeGroup = config
    ? config.groups[config.activeGroupId] || Object.values(config.groups)[0]
    : null;

  const handleTrackEnded = useCallback(async () => {
    if (!activeGroup) return;
    try {
      const res = await fetch('/api/player/ended', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({groupId: activeGroup.groupId}),
      });
      if (res.ok) {
        const updated = (await res.json()) as BotConfigState;
        setConfig(updated);
      }
    } catch {
      // Ignore
    }
  }, [activeGroup]);

  const audioState = useVoiceAudioEngine({
    currentTrack: activeGroup?.currentTrack || null,
    isPlaying: Boolean(activeGroup?.isPlaying),
    isMuted: Boolean(activeGroup?.isMuted),
    volume: activeGroup?.volume ?? 80,
    voiceCallActive: Boolean(activeGroup?.voiceCallActive),
    onTrackEnded: handleTrackEnded,
  });

  const handleRunCommand = async (payload: {
    senderId?: string;
    text: string;
    replyToMessageId?: string;
    replyToSenderId?: string;
    replyToAudioUrl?: string;
    sendToRubika?: boolean;
  }) => {
    if (!config || !activeGroup) return;
    setIsBusy(true);
    try {
      const res = await fetch('/api/command', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          groupId: activeGroup.groupId,
          senderId: payload.senderId || config.creatorId,
          text: payload.text,
          replyToMessageId: payload.replyToMessageId,
          replyToSenderId: payload.replyToSenderId,
          replyToAudioUrl: payload.replyToAudioUrl,
          sendToRubika: payload.sendToRubika,
        }),
      });
      const data = (await res.json()) as {
        state?: BotConfigState;
        botMessage?: {text: string} | null;
      };
      if (data.state) {
        setConfig(data.state);
      }
      if (data.botMessage?.text) {
        const firstLine = data.botMessage.text.split('\n')[0];
        showToast(firstLine);
      }
    } finally {
      setIsBusy(false);
    }
  };

  const handleSelectTrack = async (track: Track, mode: 'play_now' | 'queue') => {
    if (!activeGroup) return;
    setIsBusy(true);
    try {
      const res = await fetch('/api/player/select-track', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({groupId: activeGroup.groupId, track, mode}),
      });
      if (res.ok) {
        const updated = (await res.json()) as BotConfigState;
        setConfig(updated);
        showToast(
          mode === 'queue'
            ? `آهنگ «${track.title}» به صف اضافه شد.`
            : `در حال پخش در ویسکال: ${track.title}`,
        );
      }
    } finally {
      setIsBusy(false);
    }
  };

  const handleEnqueueMood = async (mood: MusicMood, count: number) => {
    if (!activeGroup) return;
    setIsBusy(true);
    try {
      const res = await fetch('/api/music/catalog/enqueue-mood', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({groupId: activeGroup.groupId, mood, count}),
      });
      const data = (await res.json()) as {addedCount?: number; state?: BotConfigState; error?: string};
      if (res.ok && data.state) {
        setConfig(data.state);
        showToast(`${data.addedCount || count} آهنگ ${mood} به صف پخش ویسکال اضافه شد.`);
      } else if (data.error) {
        showToast(data.error);
      }
    } finally {
      setIsBusy(false);
    }
  };

  const handleSetAutoShutdown = async (payload: {
    enabled: boolean;
    targetTime: string;
    stopPollingAlso: boolean;
  }) => {
    if (!activeGroup) return;
    setIsBusy(true);
    try {
      const res = await fetch(
        `/api/groups/${encodeURIComponent(activeGroup.groupId)}/auto-shutdown`,
        {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({
            ...payload,
            timezoneOffsetMinutes: new Date().getTimezoneOffset(),
          }),
        },
      );
      const data = (await res.json()) as {state?: BotConfigState; error?: string};
      if (res.ok && data.state) {
        setConfig(data.state);
        showToast(
          payload.enabled
            ? `تایمر قطع خودکار ویسکال روی ساعت ${payload.targetTime} تنظیم شد.`
            : 'تایمر خاموشی خودکار لغو شد.',
        );
      } else if (data.error) {
        showToast(data.error);
      }
    } finally {
      setIsBusy(false);
    }
  };

  const handleApplySmartPlaylist = async (payload: {
    name?: string;
    moods: MusicMood[];
    count: number;
    balanceMode: 'interleaved' | 'shuffled';
    startMode: 'replace_and_play' | 'append_queue';
    savePreset: boolean;
    customTracks?: Track[];
  }) => {
    if (!activeGroup) return;
    setIsBusy(true);
    try {
      const res = await fetch('/api/music/catalog/smart-playlist', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          groupId: activeGroup.groupId,
          ...payload,
        }),
      });
      const data = (await res.json()) as {
        addedCount?: number;
        state?: BotConfigState;
        error?: string;
      };
      if (res.ok && data.state) {
        setConfig(data.state);
        showToast(
          `پلی‌لیست هوشمند (${data.addedCount || payload.count} آهنگ) برای پخش متوالی در ویس‌چت آماده شد.`,
        );
      } else if (data.error) {
        showToast(data.error);
      }
    } finally {
      setIsBusy(false);
    }
  };

  const handleDeletePreset = async (playlistId: string) => {
    if (!activeGroup) return;
    setIsBusy(true);
    try {
      const res = await fetch(
        `/api/groups/${encodeURIComponent(activeGroup.groupId)}/playlists/${encodeURIComponent(playlistId)}`,
        {method: 'DELETE'},
      );
      if (res.ok) {
        const data = (await res.json()) as {state?: BotConfigState};
        if (data.state) setConfig(data.state);
        showToast('پلی‌لیست ذخیره‌شده حذف شد.');
      }
    } finally {
      setIsBusy(false);
    }
  };

  const handleSaveConfig = async (patch: {
    token?: string;
    creatorName?: string;
    botName?: string;
    rubikaMode?: 'bot_api_v3' | 'userbot_rubpy';
    activeGroupId?: string;
  }) => {
    setIsBusy(true);
    try {
      const res = await fetch('/api/config', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(patch),
      });
      if (res.ok) {
        const updated = (await res.json()) as BotConfigState;
        setConfig(updated);
        showToast('تنظیمات با موفقیت ذخیره شد.');
      }
    } finally {
      setIsBusy(false);
    }
  };

  const handleVerifyToken = async () => {
    setIsBusy(true);
    try {
      const res = await fetch('/api/bot/verify', {method: 'POST'});
      const data = (await res.json()) as {
        result: BotConfigState['lastVerifyResult'];
        state: BotConfigState;
      };
      setConfig(data.state);
      showToast(
        data.result.verified
          ? 'اتصال توکن به سرور روبیکا با موفقیت تایید شد.'
          : 'پاسخ از سرور روبیکا دریافت شد — جزئیات را در بخش اتصال روبیکا ببینید.',
      );
    } finally {
      setIsBusy(false);
    }
  };

  const handleTogglePolling = async (action: 'start' | 'stop') => {
    setIsBusy(true);
    try {
      const res = await fetch('/api/bot/polling', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({action}),
      });
      if (res.ok) {
        const updated = (await res.json()) as BotConfigState;
        setConfig(updated);
        showToast(
          action === 'start'
            ? 'دریافت زنده پیام‌های روبیکا فعال شد.'
            : 'دریافت پیام‌های روبیکا متوقف شد.',
        );
      }
    } finally {
      setIsBusy(false);
    }
  };

  const handleSendDirectRubika = async (chatId: string, text: string) => {
    setIsBusy(true);
    try {
      const res = await fetch('/api/bot/send-rubika', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({chatId, text}),
      });
      const data = (await res.json()) as {ok: boolean; error?: string; state?: BotConfigState};
      if (data.state) setConfig(data.state);
      showToast(data.ok ? 'پیام به گروه روبیکا ارسال شد.' : `خطای ارسال روبیکا: ${data.error || 'نامشخص'}`);
    } finally {
      setIsBusy(false);
    }
  };

  const handleAddGroup = async (payload: {title: string; rubikaChatId: string; daysValid: number}) => {
    setIsBusy(true);
    try {
      const res = await fetch('/api/groups', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        const data = (await res.json()) as {state: BotConfigState};
        setConfig(data.state);
        showToast(`گروه «${payload.title}» ثبت و فعال شد.`);
      }
    } finally {
      setIsBusy(false);
    }
  };

  const handleAddMember = async (
    groupId: string,
    payload: {name: string; userId: string; role: UserRole},
  ) => {
    setIsBusy(true);
    try {
      const res = await fetch(`/api/groups/${encodeURIComponent(groupId)}/members`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        const data = (await res.json()) as {state: BotConfigState};
        setConfig(data.state);
        showToast(`کاربر «${payload.name}» به گروه اضافه شد.`);
      }
    } finally {
      setIsBusy(false);
    }
  };

  if (!config || !activeGroup) {
    return (
      <div className="min-h-screen bg-[#0B0F17] flex items-center justify-center p-6 text-slate-300 text-sm">
        در حال بارگذاری هسته ربات موزیکال روبیکا...
      </div>
    );
  }

  const remainingDays = Math.max(
    0,
    Math.ceil(
      (new Date(activeGroup.subscription.expiresAt).getTime() - Date.now()) / (1000 * 60 * 60 * 24),
    ),
  );

  const activeTabInfo = NAV_ITEMS.find((n) => n.key === activeTab) || NAV_ITEMS[0];

  return (
    <div className="min-h-screen bg-[#0B0F17] text-slate-100 flex">
      {/* Mobile Sidebar Backdrop */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-40 lg:hidden"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}

      {/* Right Sidebar (RTL Navigation) */}
      <aside
        className={`fixed lg:static inset-y-0 right-0 z-50 w-[268px] shrink-0 bg-[#111827] border-l border-slate-800 flex flex-col justify-between transition-transform duration-200 ${
          mobileMenuOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="p-5 space-y-6">
          {/* Brand Profile */}
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <img
                src="/src/assets/images/bot_studio_avatar_1794902867918.jpg"
                alt="آواتار ربات موزیکال پریا چش رنگی"
                referrerPolicy="no-referrer"
                className="w-10 h-10 rounded-lg object-cover border border-slate-700 shrink-0"
              />
              <div className="min-w-0">
                <p className="text-sm font-bold text-slate-100 truncate">ربات موزیکال روبیکا</p>
                <p className="text-xs text-emerald-400 truncate">سازنده: {config.creatorName}</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setMobileMenuOpen(false)}
              className="lg:hidden text-slate-400 hover:text-white cursor-pointer"
              aria-label="بستن منو"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Active Group Selector */}
          <div className="space-y-1.5">
            <label className="block text-xs text-slate-400">گروه فعال</label>
            <select
              value={activeGroup.groupId}
              onChange={(e) => void handleSaveConfig({activeGroupId: e.target.value})}
              className="w-full bg-[#0B0F17] border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-100 outline-none"
            >
              {Object.values(config.groups).map((g) => (
                <option key={g.groupId} value={g.groupId}>
                  {g.title}
                </option>
              ))}
            </select>
          </div>

          {/* Navigation Links */}
          <nav className="space-y-1">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.key;
              return (
                <button
                  key={item.key}
                  type="button"
                  onClick={() => {
                    setActiveTab(item.key);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
                    isActive
                      ? 'bg-emerald-600/15 text-emerald-300 border border-emerald-500/30'
                      : 'text-slate-300 hover:bg-slate-800/60 hover:text-white border border-transparent'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom Sidebar Summary */}
        <div className="p-5 border-t border-slate-800 space-y-3 text-xs">
          <div className="flex items-center justify-between text-slate-400">
            <span>وضعیت اتصال روبیکا</span>
            <span className={config.pollingActive ? 'text-emerald-400 font-medium' : 'text-slate-300'}>
              {config.pollingActive ? 'دریافت زنده فعال' : 'آماده'}
            </span>
          </div>
          <div className="flex items-center justify-between text-slate-400">
            <span>اعتبار اشتراک گروه</span>
            <span className="font-mono tabular-nums text-slate-200">{remainingDays} روز</span>
          </div>
          <a
            href="/api/export/github-apk-zip"
            download="parya-rubika-music-bot-apk-github.zip"
            className="w-full py-2 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-100 font-medium flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span>دانلود پکیج APK گیت‌هاب</span>
          </a>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Top Bar Contract: 3 clean zones separated by gap-8 */}
        <header className="h-16 px-4 sm:px-6 border-b border-slate-800 bg-[#111827]/90 flex items-center justify-between gap-8 sticky top-0 z-30">
          {/* Zone 1: Brand / Section */}
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-2 rounded-lg bg-slate-800 text-slate-200 cursor-pointer"
              aria-label="باز کردن منو"
            >
              <Menu className="w-4 h-4" />
            </button>
            <h1 className="text-base font-bold text-slate-100 whitespace-nowrap shrink-0">
              {activeTabInfo.label}
            </h1>
          </div>

          {/* Zone 2: Quick single-line tab links on desktop */}
          <nav className="hidden xl:flex items-center gap-6 text-sm text-slate-400">
            {NAV_ITEMS.slice(0, 4).map((item) => (
              <button
                key={item.key}
                type="button"
                onClick={() => setActiveTab(item.key)}
                className={`whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                  activeTab === item.key ? 'text-emerald-400 font-medium' : 'hover:text-slate-100'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Zone 3: 1 Primary Action */}
          <div className="shrink-0">
            <button
              type="button"
              disabled={isBusy}
              onClick={() => handleTogglePolling(config.pollingActive ? 'stop' : 'start')}
              className={`px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                config.pollingActive
                  ? 'bg-red-500/15 text-red-400 border border-red-500/30 hover:bg-red-500/25'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white'
              }`}
            >
              {config.pollingActive ? <Square className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>{config.pollingActive ? 'توقف ربات روبیکا' : 'اجرای زنده ربات روبیکا'}</span>
            </button>
          </div>
        </header>

        {/* Feedback Toast */}
        {toastMsg && (
          <div className="mx-4 sm:mx-6 mt-4 px-4 py-2.5 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-xs text-emerald-200 flex items-center justify-between gap-3">
            <span className="truncate">{toastMsg}</span>
            <button
              type="button"
              onClick={() => setToastMsg(null)}
              className="text-emerald-300 hover:text-white cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Viewport Content */}
        <main className="flex-1 p-4 sm:p-6 max-w-[1400px] w-full mx-auto">
          {activeTab === 'voice' && (
            <VoiceCallStudioView
              group={activeGroup}
              isBusy={isBusy}
              audioState={audioState}
              onRunCommand={(text) => handleRunCommand({text})}
              onSelectTrack={handleSelectTrack}
              onEnqueueMood={handleEnqueueMood}
              onSetAutoShutdown={handleSetAutoShutdown}
              onApplySmartPlaylist={handleApplySmartPlaylist}
              onDeletePreset={handleDeletePreset}
            />
          )}

          {activeTab === 'chat' && (
            <GroupChatConsoleView
              group={activeGroup}
              creatorId={config.creatorId}
              isBusy={isBusy}
              onExecuteCommand={handleRunCommand}
            />
          )}

          {activeTab === 'analytics' && (
            <AnalyticsD3View
              group={activeGroup}
              isBusy={isBusy}
              onQuickPlayRandom={() => handleRunCommand({text: 'پخش رندوم'})}
              onNavigateToVoice={() => setActiveTab('voice')}
            />
          )}

          {activeTab === 'groups' && (
            <GroupsAccessView
              config={config}
              activeGroup={activeGroup}
              isBusy={isBusy}
              onSelectGroup={(groupId) => handleSaveConfig({activeGroupId: groupId})}
              onAddGroup={handleAddGroup}
              onAddMember={handleAddMember}
              onRunCommand={handleRunCommand}
            />
          )}

          {activeTab === 'rubika' && (
            <RubikaConnectionView
              config={config}
              activeGroup={activeGroup}
              isBusy={isBusy}
              onSaveConfig={handleSaveConfig}
              onVerifyToken={handleVerifyToken}
              onTogglePolling={handleTogglePolling}
              onSendDirectRubika={handleSendDirectRubika}
            />
          )}

          {activeTab === 'apk' && (
            <PythonApkExportView token={config.token} creatorName={config.creatorName} />
          )}
        </main>
      </div>
    </div>
  );
}
