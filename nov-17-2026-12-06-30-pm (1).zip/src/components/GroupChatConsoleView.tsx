import React, {useEffect, useRef, useState} from 'react';
import {CornerDownLeft, Music2, Reply, Send, UserCheck, X} from 'lucide-react';
import {ChatMessage, GroupState, UserRole} from '../types/bot';

interface GroupChatConsoleViewProps {
  group: GroupState;
  creatorId: string;
  isBusy: boolean;
  onExecuteCommand: (payload: {
    senderId: string;
    text: string;
    replyToMessageId?: string;
    replyToSenderId?: string;
    replyToAudioUrl?: string;
    sendToRubika?: boolean;
  }) => Promise<void>;
}

const ROLE_BADGE_TEXT: Record<UserRole, string> = {
  creator: 'سازنده ربات',
  owner: 'مالک گروه',
  admin: 'ادمین',
  vip: 'ویژه',
  member: 'عادی',
};

const QUICK_COMMANDS: Array<{label: string; cmd: string}> = [
  {label: 'راهنما', cmd: 'راهنما'},
  {label: 'آهنگ شاد', cmd: 'آهنگ شاد'},
  {label: 'آهنگ غمگین', cmd: 'آهنگ غمگین'},
  {label: 'آهنگ لری', cmd: 'آهنگ لری'},
  {label: 'آمار آرشیو', cmd: 'آمار آرشیو'},
  {label: 'ساخت کال', cmd: 'ساخت کال'},
  {label: 'پخش ریپلای', cmd: 'پخش ریپلای'},
  {label: 'پخش رندوم', cmd: 'پخش رندوم'},
  {label: 'بعدی', cmd: 'بعدی'},
  {label: 'قبلی', cmd: 'قبلی'},
  {label: 'صف', cmd: 'صف'},
  {label: 'تاریخچه آهنگها', cmd: 'تاریخچه آهنگها'},
  {label: 'تنظیم صدا 50', cmd: 'تنظیم صدا 50'},
  {label: 'بیصدا', cmd: 'بیصدا'},
  {label: 'باصدا', cmd: 'باصدا'},
  {label: 'توقف آهنگ', cmd: 'توقف آهنگ'},
  {label: 'ادامه آهنگ', cmd: 'ادامه آهنگ'},
  {label: 'قطع ویسکال', cmd: 'قطع ویسکال'},
  {label: 'تنظیم خاموشی 23:30', cmd: 'تنظیم خاموشی 23:30'},
  {label: 'لغو خاموشی', cmd: 'لغو خاموشی'},
  {label: 'وضعیت تایمر', cmd: 'وضعیت تایمر'},
  {label: 'مالک گروه', cmd: 'مالک گروه'},
  {label: 'ویژه (ریپلای)', cmd: 'ویژه'},
  {label: 'حذف ویژه (ریپلای)', cmd: 'حذف ویژه'},
  {label: 'تنظیم مالک (ریپلای)', cmd: 'تنظیم مالک'},
  {label: 'دسترسی عموم باز', cmd: 'دسترسی عموم باز'},
  {label: 'دسترسی عموم قفل باشد', cmd: 'دسترسی عموم قفل باشد'},
  {label: 'مقام', cmd: 'مقام'},
  {label: 'وضعیت', cmd: 'وضعیت'},
];

export const GroupChatConsoleView: React.FC<GroupChatConsoleViewProps> = ({
  group,
  creatorId,
  isBusy,
  onExecuteCommand,
}) => {
  const [selectedSenderId, setSelectedSenderId] = useState<string>(creatorId);
  const [inputText, setInputText] = useState('');
  const [replyTarget, setReplyTarget] = useState<ChatMessage | null>(null);
  const [sendToRubika, setSendToRubika] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!group.members.some((m) => m.userId === selectedSenderId) && group.members.length > 0) {
      setSelectedSenderId(group.members[0].userId);
    }
  }, [group.members, selectedSenderId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({behavior: 'smooth'});
  }, [group.messages.length]);

  const handleSend = async (commandOverride?: string) => {
    const text = (commandOverride ?? inputText).trim();
    if (!text) return;
    if (!commandOverride) setInputText('');

    await onExecuteCommand({
      senderId: selectedSenderId,
      text,
      replyToMessageId: replyTarget?.id,
      replyToSenderId: replyTarget?.senderId,
      replyToAudioUrl: replyTarget?.audioAttachment?.url,
      sendToRubika,
    });
    setReplyTarget(null);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Main Group Chat Stream */}
      <div className="lg:col-span-8 bg-[#111827] border border-slate-800 rounded-xl flex flex-col h-[640px] overflow-hidden">
        {/* Chat Header */}
        <div className="px-5 py-3.5 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-semibold text-slate-100">{group.title}</h3>
            <p className="text-xs text-slate-400">
              شناسه چت روبیکا: <span className="font-mono">{group.rubikaChatId}</span> ·{' '}
              {group.publicAccess === 'open' ? 'دسترسی عموم باز' : 'دسترسی قفل'}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={sendToRubika}
                onChange={(e) => setSendToRubika(e.target.checked)}
                className="accent-emerald-500 rounded cursor-pointer"
              />
              <span>ارسال پاسخ واقعی به روبیکا</span>
            </label>
          </div>
        </div>

        {/* Messages Feed */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3 bg-[#0B0F17]/60">
          {group.messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.isBot ? 'items-start' : 'items-end'}`}
            >
              <div
                className={`max-w-[85%] rounded-xl px-4 py-3 border ${
                  msg.isBot
                    ? 'bg-[#141D2F] border-slate-800 text-slate-100'
                    : 'bg-emerald-950/40 border-emerald-800/50 text-slate-100'
                }`}
              >
                <div className="flex items-center justify-between gap-4 mb-1.5">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="font-semibold text-emerald-400">{msg.senderName}</span>
                    {!msg.isBot && (
                      <span className="text-slate-400">· {ROLE_BADGE_TEXT[msg.senderRole]}</span>
                    )}
                    {msg.deliveredToRubika && (
                      <span className="text-emerald-400">· ارسال‌شده به روبیکا</span>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => setReplyTarget(msg)}
                    className="text-xs text-slate-400 hover:text-emerald-400 flex items-center gap-1 cursor-pointer"
                    title="ریپلای روی این پیام"
                  >
                    <Reply className="w-3.5 h-3.5" />
                    <span>ریپلای</span>
                  </button>
                </div>

                {msg.replyPreview && (
                  <div className="mb-2 px-2.5 py-1.5 rounded bg-black/25 text-xs text-slate-400 truncate border border-slate-800/70">
                    پاسخ به: {msg.replyPreview}
                  </div>
                )}

                <p className="text-sm whitespace-pre-wrap leading-relaxed">{msg.text}</p>

                {msg.audioAttachment && (
                  <div className="mt-2.5 pt-2.5 border-t border-slate-800/80 flex items-center gap-2 text-xs text-emerald-300">
                    <Music2 className="w-4 h-4 shrink-0" />
                    <span className="truncate">
                      فایل صوتی: {msg.audioAttachment.title}
                      {msg.audioAttachment.artist ? ` — ${msg.audioAttachment.artist}` : ''}
                    </span>
                  </div>
                )}

                <div className="mt-1.5 text-[11px] text-slate-500 font-mono tabular-nums text-left">
                  {new Date(msg.timestamp).toLocaleTimeString('fa-IR')}
                </div>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        {/* Reply Indicator */}
        {replyTarget && (
          <div className="px-4 py-2 bg-slate-900 border-t border-slate-800 flex items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 min-w-0 text-slate-300">
              <CornerDownLeft className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span className="truncate">
                در حال ریپلای به <strong className="text-emerald-300">{replyTarget.senderName}</strong>:{' '}
                {replyTarget.text.slice(0, 60)}
              </span>
            </div>
            <button
              type="button"
              onClick={() => setReplyTarget(null)}
              className="text-slate-400 hover:text-white cursor-pointer"
              aria-label="لغو ریپلای"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Composer */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void handleSend();
          }}
          className="p-3.5 border-t border-slate-800 bg-[#111827] flex flex-wrap sm:flex-nowrap items-center gap-2.5"
        >
          <div className="flex items-center gap-2 shrink-0">
            <UserCheck className="w-4 h-4 text-slate-400" />
            <select
              value={selectedSenderId}
              onChange={(e) => setSelectedSenderId(e.target.value)}
              aria-label="ارسال با هویت کاربر"
              className="bg-[#0B0F17] border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-200 outline-none"
            >
              {group.members.map((m) => (
                <option key={m.userId} value={m.userId}>
                  {m.name} ({ROLE_BADGE_TEXT[m.role]})
                </option>
              ))}
            </select>
          </div>

          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="دستور ربات را بنویسید (مثلاً: آهنگ لری، ویژه، ساخت کال، راهنما)..."
            className="flex-1 min-w-[200px] bg-[#0B0F17] border border-slate-800 focus:border-emerald-500 rounded-lg px-3.5 py-2 text-sm text-slate-100 placeholder:text-slate-500 outline-none"
          />

          <button
            type="submit"
            disabled={isBusy || !inputText.trim()}
            className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white text-sm font-medium flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>ارسال دستور</span>
          </button>
        </form>
      </div>

      {/* Quick Commands Reference & 1-Click Runner */}
      <aside className="lg:col-span-4 bg-[#111827] border border-slate-800 rounded-xl p-5 space-y-4">
        <div>
          <h3 className="text-base font-semibold text-slate-100">اجرای سریع دستورات ربات</h3>
          <p className="text-xs text-slate-400 mt-1">
            برای دستورات نیازمند ریپلای (مثل «ویژه»، «حذف ویژه»، «تنظیم مالک»، «پخش ریپلای») ابتدا روی یکی از پیام‌های چت دکمه «ریپلای» را بزنید.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          {QUICK_COMMANDS.map((item) => (
            <button
              key={item.cmd}
              type="button"
              disabled={isBusy}
              onClick={() => void handleSend(item.cmd)}
              className="px-3 py-1.5 rounded-lg bg-[#0B0F17] hover:bg-slate-800 border border-slate-800 text-xs text-slate-200 transition-colors whitespace-nowrap cursor-pointer"
            >
              {item.label}
            </button>
          ))}
        </div>

        <div className="pt-4 border-t border-slate-800 text-xs text-slate-400 space-y-2">
          <p className="text-slate-200 font-medium">دستورات دارای پارامتر:</p>
          <ul className="space-y-1.5 list-disc list-inside">
            <li>
              <code className="font-mono text-emerald-400">آهنگ لری</code> — جستجو و پخش در ویسکال
            </li>
            <li>
              <code className="font-mono text-emerald-400">پخش ویسکال https://...</code> — لینک مستقیم
            </li>
            <li>
              <code className="font-mono text-emerald-400">حذف از صف 2</code> — حذف آیتم از صف
            </li>
            <li>
              <code className="font-mono text-emerald-400">تنظیم صدا 50</code> — تنظیم ولوم ۰ تا ۱۰۰
            </li>
          </ul>
        </div>
      </aside>
    </div>
  );
};
