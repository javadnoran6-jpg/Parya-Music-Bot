import React, {useState} from 'react';
import {Calendar, Crown, Lock, Plus, Shield, Unlock, UserPlus} from 'lucide-react';
import {BotConfigState, GroupState, UserRole} from '../types/bot';

interface GroupsAccessViewProps {
  config: BotConfigState;
  activeGroup: GroupState;
  isBusy: boolean;
  onSelectGroup: (groupId: string) => Promise<void>;
  onAddGroup: (payload: {title: string; rubikaChatId: string; daysValid: number}) => Promise<void>;
  onAddMember: (groupId: string, payload: {name: string; userId: string; role: UserRole}) => Promise<void>;
  onRunCommand: (payload: {senderId: string; text: string; replyToSenderId?: string}) => Promise<void>;
}

const ROLE_LABELS: Record<UserRole, string> = {
  creator: 'سازنده ربات',
  owner: 'مالک گروه',
  admin: 'ادمین',
  vip: 'کاربر ویژه',
  member: 'کاربر عادی',
};

export const GroupsAccessView: React.FC<GroupsAccessViewProps> = ({
  config,
  activeGroup,
  isBusy,
  onSelectGroup,
  onAddGroup,
  onAddMember,
  onRunCommand,
}) => {
  const [newGroupTitle, setNewGroupTitle] = useState('');
  const [newGroupChatId, setNewGroupChatId] = useState('');
  const [newGroupDays, setNewGroupDays] = useState(30);

  const [memberName, setMemberName] = useState('');
  const [memberId, setMemberId] = useState('');
  const [memberRole, setMemberRole] = useState<UserRole>('member');

  const expiresDate = new Date(activeGroup.subscription.expiresAt);
  const purchasedDate = new Date(activeGroup.subscription.purchasedAt);
  const remainingDays = Math.max(
    0,
    Math.ceil((expiresDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24)),
  );

  return (
    <div className="space-y-6">
      {/* Subscription & Access Overview */}
      <section className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-4">
          <p className="text-xs text-slate-400">مالک فعلی گروه</p>
          <p className="text-base font-semibold text-slate-100 mt-1 truncate">{activeGroup.ownerName}</p>
          <p className="text-xs font-mono text-slate-400 mt-1">{activeGroup.ownerId}</p>
        </div>

        <div className="bg-[#111827] border border-slate-800 rounded-xl p-4">
          <p className="text-xs text-slate-400">تاریخ خرید اشتراک</p>
          <p className="text-base font-semibold text-slate-100 mt-1 tabular-nums">
            {purchasedDate.toLocaleDateString('fa-IR')}
          </p>
          <p className="text-xs text-slate-400 mt-1">{activeGroup.subscription.planName}</p>
        </div>

        <div className="bg-[#111827] border border-slate-800 rounded-xl p-4">
          <p className="text-xs text-slate-400">انقضا و روزهای باقیمانده</p>
          <p className="text-base font-semibold text-emerald-400 mt-1 tabular-nums">
            {remainingDays} روز باقیمانده
          </p>
          <p className="text-xs text-slate-400 mt-1 tabular-nums">
            انقضا: {expiresDate.toLocaleDateString('fa-IR')}
          </p>
        </div>

        <div className="bg-[#111827] border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <p className="text-xs text-slate-400">دسترسی عمومی گروه</p>
            <p className="text-base font-semibold text-slate-100 mt-1">
              {activeGroup.publicAccess === 'open' ? 'باز برای همه اعضا' : 'قفل (فقط ویژه و ادمین)'}
            </p>
          </div>
          <button
            type="button"
            disabled={isBusy}
            onClick={() =>
              onRunCommand({
                senderId: config.creatorId,
                text: activeGroup.publicAccess === 'open' ? 'دسترسی عموم قفل باشد' : 'دسترسی عموم باز',
              })
            }
            className={`mt-2 px-3 py-1.5 rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer ${
              activeGroup.publicAccess === 'open'
                ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30 hover:bg-amber-500/25'
                : 'bg-emerald-600 text-white hover:bg-emerald-500'
            }`}
          >
            {activeGroup.publicAccess === 'open' ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
            <span>{activeGroup.publicAccess === 'open' ? 'قفل کردن دسترسی عموم' : 'باز کردن دسترسی عموم'}</span>
          </button>
        </div>
      </section>

      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Members & Role Management */}
        <div className="lg:col-span-7 bg-[#111827] border border-slate-800 rounded-xl p-5 space-y-5">
          <div className="flex items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-semibold text-slate-100">اعضا، کاربران ویژه و مالکیت گروه</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                مدیریت واقعی مقام‌ها مطابق دستورات «تنظیم مالک»، «ویژه» و «حذف ویژه»
              </p>
            </div>
            <Calendar className="w-4 h-4 text-slate-500" />
          </div>

          <div className="divide-y divide-slate-800/80">
            {activeGroup.members.map((m) => (
              <div key={m.userId} className="py-3 flex flex-wrap items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm font-medium text-slate-100">{m.name}</p>
                  <p className="text-xs text-slate-400">
                    {ROLE_LABELS[m.role]} · <span className="font-mono">{m.userId}</span>
                  </p>
                </div>

                {m.role !== 'creator' && (
                  <div className="flex items-center gap-1.5 shrink-0">
                    {m.role !== 'vip' && m.role !== 'owner' && (
                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() =>
                          onRunCommand({
                            senderId: config.creatorId,
                            text: 'ویژه',
                            replyToSenderId: m.userId,
                          })
                        }
                        className="px-2.5 py-1.5 rounded bg-emerald-600/15 hover:bg-emerald-600/25 text-emerald-300 border border-emerald-500/30 text-xs font-medium whitespace-nowrap cursor-pointer"
                      >
                        ویژه کردن
                      </button>
                    )}

                    {m.role === 'vip' && (
                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() =>
                          onRunCommand({
                            senderId: config.creatorId,
                            text: 'حذف ویژه',
                            replyToSenderId: m.userId,
                          })
                        }
                        className="px-2.5 py-1.5 rounded bg-red-500/15 hover:bg-red-500/25 text-red-300 border border-red-500/30 text-xs font-medium whitespace-nowrap cursor-pointer"
                      >
                        حذف ویژه
                      </button>
                    )}

                    {m.role !== 'owner' && (
                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() =>
                          onRunCommand({
                            senderId: config.creatorId,
                            text: 'تنظیم مالک',
                            replyToSenderId: m.userId,
                          })
                        }
                        className="px-2.5 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1 whitespace-nowrap cursor-pointer"
                      >
                        <Crown className="w-3.5 h-3.5 text-amber-400" />
                        <span>تنظیم مالک</span>
                      </button>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Add Member Form */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!memberName.trim() || !memberId.trim()) return;
              void onAddMember(activeGroup.groupId, {
                name: memberName,
                userId: memberId,
                role: memberRole,
              });
              setMemberName('');
              setMemberId('');
            }}
            className="pt-4 border-t border-slate-800 grid grid-cols-1 sm:grid-cols-12 gap-2.5"
          >
            <input
              type="text"
              value={memberName}
              onChange={(e) => setMemberName(e.target.value)}
              placeholder="نام کاربر"
              className="sm:col-span-4 bg-[#0B0F17] border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-100 outline-none"
            />
            <input
              type="text"
              dir="ltr"
              value={memberId}
              onChange={(e) => setMemberId(e.target.value)}
              placeholder="Rubika User ID"
              className="sm:col-span-3 bg-[#0B0F17] border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-100 outline-none text-left"
            />
            <select
              value={memberRole}
              onChange={(e) => setMemberRole(e.target.value as UserRole)}
              className="sm:col-span-3 bg-[#0B0F17] border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-200 outline-none"
            >
              <option value="member">عادی</option>
              <option value="vip">ویژه</option>
              <option value="admin">ادمین</option>
              <option value="owner">مالک گروه</option>
            </select>
            <button
              type="submit"
              disabled={!memberName.trim() || !memberId.trim()}
              className="sm:col-span-2 py-2 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white text-xs font-medium flex items-center justify-center gap-1 cursor-pointer"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>افزودن</span>
            </button>
          </form>
        </div>

        {/* Connected Rubika Groups List & Add Group */}
        <div className="lg:col-span-5 bg-[#111827] border border-slate-800 rounded-xl p-5 space-y-5">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-emerald-400" />
            <h3 className="text-base font-semibold text-slate-100">گروه‌های متصل روبیکا</h3>
          </div>

          <div className="space-y-2">
            {Object.values(config.groups).map((g) => {
              const isSelected = g.groupId === activeGroup.groupId;
              return (
                <button
                  key={g.groupId}
                  type="button"
                  onClick={() => onSelectGroup(g.groupId)}
                  className={`w-full text-right p-3 rounded-lg border transition-colors cursor-pointer ${
                    isSelected
                      ? 'bg-emerald-500/10 border-emerald-500/40 text-slate-100'
                      : 'bg-[#0B0F17] border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-medium truncate">{g.title}</span>
                    <span className="text-xs font-mono text-slate-400">{g.rubikaChatId}</span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">
                    {g.voiceCallActive ? 'ویسکال فعال' : 'آماده'} · {g.members.length} عضو ·{' '}
                    {g.publicAccess === 'open' ? 'دسترسی باز' : 'دسترسی قفل'}
                  </p>
                </button>
              );
            })}
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!newGroupTitle.trim() || !newGroupChatId.trim()) return;
              void onAddGroup({
                title: newGroupTitle,
                rubikaChatId: newGroupChatId,
                daysValid: newGroupDays,
              });
              setNewGroupTitle('');
              setNewGroupChatId('');
            }}
            className="pt-4 border-t border-slate-800 space-y-3"
          >
            <p className="text-xs font-semibold text-slate-200">افزودن گروه جدید روبیکا</p>
            <input
              type="text"
              value={newGroupTitle}
              onChange={(e) => setNewGroupTitle(e.target.value)}
              placeholder="نام گروه (مثلاً: گروه دورهمی موزیک)"
              className="w-full bg-[#0B0F17] border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-100 outline-none"
            />
            <div className="grid grid-cols-3 gap-2">
              <input
                type="text"
                dir="ltr"
                value={newGroupChatId}
                onChange={(e) => setNewGroupChatId(e.target.value)}
                placeholder="Chat ID (g0...)"
                className="col-span-2 bg-[#0B0F17] border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-100 outline-none text-left"
              />
              <input
                type="number"
                min={1}
                max={365}
                value={newGroupDays}
                onChange={(e) => setNewGroupDays(Number(e.target.value))}
                placeholder="روز اشتراک"
                className="bg-[#0B0F17] border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-100 outline-none"
              />
            </div>
            <button
              type="submit"
              disabled={!newGroupTitle.trim() || !newGroupChatId.trim()}
              className="w-full py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>ثبت و اتصال گروه</span>
            </button>
          </form>
        </div>
      </section>
    </div>
  );
};
