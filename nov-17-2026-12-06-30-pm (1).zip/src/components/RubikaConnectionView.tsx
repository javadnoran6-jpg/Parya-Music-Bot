import React, {useState} from 'react';
import {CheckCircle2, Copy, KeyRound, Play, RefreshCw, Send, Square, Webhook} from 'lucide-react';
import {BotConfigState, GroupState} from '../types/bot';

interface RubikaConnectionViewProps {
  config: BotConfigState;
  activeGroup: GroupState;
  isBusy: boolean;
  onSaveConfig: (patch: {
    token?: string;
    creatorName?: string;
    botName?: string;
    rubikaMode?: 'bot_api_v3' | 'userbot_rubpy';
  }) => Promise<void>;
  onVerifyToken: () => Promise<void>;
  onTogglePolling: (action: 'start' | 'stop') => Promise<void>;
  onSendDirectRubika: (chatId: string, text: string) => Promise<void>;
}

export const RubikaConnectionView: React.FC<RubikaConnectionViewProps> = ({
  config,
  activeGroup,
  isBusy,
  onSaveConfig,
  onVerifyToken,
  onTogglePolling,
  onSendDirectRubika,
}) => {
  const [tokenInput, setTokenInput] = useState(config.token);
  const [creatorInput, setCreatorInput] = useState(config.creatorName);
  const [botNameInput, setBotNameInput] = useState(config.botName);
  const [directChatId, setDirectChatId] = useState(activeGroup.rubikaChatId);
  const [directText, setDirectText] = useState('🎵 ربات موزیکال پریا چش رنگی با موفقیت به گروه متصل شد.');
  const [copiedWebhook, setCopiedWebhook] = useState(false);

  const webhookUrl = `${window.location.origin}/api/rubika/webhook`;

  const copyWebhook = () => {
    void navigator.clipboard.writeText(webhookUrl);
    setCopiedWebhook(true);
    setTimeout(() => setCopiedWebhook(false), 1800);
  };

  return (
    <div className="space-y-6">
      {/* Token & Rubika API Configuration */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 bg-[#111827] border border-slate-800 rounded-xl p-6 space-y-5">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h3 className="text-base font-semibold text-slate-100">تنظیمات توکن و اتصال واقعی روبیکا</h3>
              <p className="text-xs text-slate-400 mt-1">
                ارتباط مستقیم با سرور رسمی <span className="font-mono">botapi.rubika.ir/v3</span> و پشتیبانی از حالت Userbot پایتون
              </p>
            </div>
            <KeyRound className="w-5 h-5 text-emerald-400 shrink-0" />
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs text-slate-300 mb-1.5">توکن ربات روبیکا (Rubika Bot Token)</label>
              <input
                type="text"
                dir="ltr"
                value={tokenInput}
                onChange={(e) => setTokenInput(e.target.value)}
                className="w-full bg-[#0B0F17] border border-slate-800 focus:border-emerald-500 rounded-lg px-3.5 py-2.5 text-xs font-mono text-emerald-300 outline-none text-left"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-slate-300 mb-1.5">نام سازنده ربات</label>
                <input
                  type="text"
                  value={creatorInput}
                  onChange={(e) => setCreatorInput(e.target.value)}
                  className="w-full bg-[#0B0F17] border border-slate-800 focus:border-emerald-500 rounded-lg px-3.5 py-2 text-sm text-slate-100 outline-none"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-300 mb-1.5">نام نمایشی ربات</label>
                <input
                  type="text"
                  value={botNameInput}
                  onChange={(e) => setBotNameInput(e.target.value)}
                  className="w-full bg-[#0B0F17] border border-slate-800 focus:border-emerald-500 rounded-lg px-3.5 py-2 text-sm text-slate-100 outline-none"
                />
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                type="button"
                disabled={isBusy}
                onClick={() =>
                  onSaveConfig({
                    token: tokenInput,
                    creatorName: creatorInput,
                    botName: botNameInput,
                  })
                }
                className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs font-medium cursor-pointer"
              >
                ذخیره تنظیمات
              </button>

              <button
                type="button"
                disabled={isBusy}
                onClick={onVerifyToken}
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium flex items-center gap-1.5 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>بررسی و اتصال توکن (getMe)</span>
              </button>

              <button
                type="button"
                disabled={isBusy}
                onClick={() => onTogglePolling(config.pollingActive ? 'stop' : 'start')}
                className={`px-4 py-2 rounded-lg text-xs font-medium flex items-center gap-1.5 cursor-pointer ${
                  config.pollingActive
                    ? 'bg-red-500/15 text-red-400 border border-red-500/30 hover:bg-red-500/25'
                    : 'bg-amber-500 text-slate-950 hover:bg-amber-400 font-semibold'
                }`}
              >
                {config.pollingActive ? <Square className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                <span>{config.pollingActive ? 'توقف دریافت پیام‌ها (Polling)' : 'شروع دریافت زنده پیام‌های روبیکا'}</span>
              </button>
            </div>
          </div>

          {/* Real API verification result */}
          {config.lastVerifyResult.checkedAt && (
            <div
              className={`p-3.5 rounded-lg border text-xs ${
                config.lastVerifyResult.verified
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                  : 'bg-amber-500/10 border-amber-500/30 text-amber-300'
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="font-semibold">
                  {config.lastVerifyResult.verified
                    ? 'اتصال توکن به سرور روبیکا تایید شد'
                    : 'پاسخ سرور روبیکا در بررسی توکن'}
                </span>
                <span className="font-mono tabular-nums">
                  {new Date(config.lastVerifyResult.checkedAt).toLocaleTimeString('fa-IR')}
                </span>
              </div>
              <p className="mt-1.5 font-mono text-[11px] break-all opacity-90" dir="ltr">
                {config.lastVerifyResult.error || JSON.stringify(config.lastVerifyResult.botInfo)}
              </p>
            </div>
          )}
        </div>

        {/* Webhook + Direct Send to Rubika Group */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 space-y-3">
            <div className="flex items-center gap-2">
              <Webhook className="w-4 h-4 text-emerald-400" />
              <h3 className="text-sm font-semibold text-slate-100">آدرس Webhook رسمی روبیکا</h3>
            </div>
            <p className="text-xs text-slate-400">
              این آدرس را می‌توانید در پنل ربات‌ساز روبیکا تنظیم کنید تا پیام‌های گروه‌ها آنی دریافت شوند:
            </p>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                dir="ltr"
                value={webhookUrl}
                className="flex-1 bg-[#0B0F17] border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-300 text-left outline-none"
              />
              <button
                type="button"
                onClick={copyWebhook}
                className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs flex items-center gap-1 cursor-pointer"
              >
                {copiedWebhook ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedWebhook ? 'کپی شد' : 'کپی'}</span>
              </button>
            </div>
          </div>

          <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 space-y-3">
            <h3 className="text-sm font-semibold text-slate-100">ارسال مستقیم پیام تست به گروه روبیکا</h3>
            <input
              type="text"
              dir="ltr"
              value={directChatId}
              onChange={(e) => setDirectChatId(e.target.value)}
              placeholder="Rubika Chat ID"
              className="w-full bg-[#0B0F17] border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-100 text-left outline-none"
            />
            <textarea
              rows={2}
              value={directText}
              onChange={(e) => setDirectText(e.target.value)}
              className="w-full bg-[#0B0F17] border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-100 outline-none resize-none"
            />
            <button
              type="button"
              disabled={isBusy || !directChatId.trim() || !directText.trim()}
              onClick={() => onSendDirectRubika(directChatId, directText)}
              className="w-full py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>ارسال به روبیکا (sendMessage)</span>
            </button>
          </div>
        </div>
      </section>

      {/* Real Rubika API Request Log */}
      <section className="bg-[#111827] border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-semibold text-slate-100">گزارش واقعی ارتباط با API روبیکا</h3>
          <span className="text-xs text-slate-400 font-mono tabular-nums">{config.apiLogs.length} رویداد</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-xs text-slate-400">
                <th className="py-2 px-3 font-medium">زمان</th>
                <th className="py-2 px-3 font-medium">متد API</th>
                <th className="py-2 px-3 font-medium">وضعیت</th>
                <th className="py-2 px-3 font-medium">جزئیات پاسخ سرور</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70 text-xs">
              {config.apiLogs.slice(0, 20).map((log) => (
                <tr key={log.id} className="hover:bg-slate-800/30">
                  <td className="py-2.5 px-3 font-mono tabular-nums text-slate-400 whitespace-nowrap">
                    {new Date(log.timestamp).toLocaleTimeString('fa-IR')}
                  </td>
                  <td className="py-2.5 px-3 font-mono text-slate-200 whitespace-nowrap">{log.method}</td>
                  <td className="py-2.5 px-3 whitespace-nowrap">
                    <span
                      className={
                        log.status === 'ok'
                          ? 'text-emerald-400'
                          : log.status === 'error'
                            ? 'text-red-400'
                            : 'text-slate-300'
                      }
                    >
                      {log.status === 'ok' ? 'موفق' : log.status === 'error' ? 'خطا' : 'اطلاعات'}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-slate-300 max-w-xl truncate">{log.detail}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
