import React, {useState} from 'react';
import {Check, Layers, ListPlus, Play, RefreshCw, Shuffle, Trash2, X} from 'lucide-react';
import {GroupState, MusicMood, SmartPlaylistPreset, Track} from '../types/bot';

const ALL_MOODS: MusicMood[] = [
  'شاد',
  'غمگین',
  'محلی و لری',
  'سنتی',
  'پاپ',
  'نوستالژی',
  'آرام',
];

interface SmartPlaylistBuilderProps {
  group: GroupState;
  isBusy: boolean;
  onApplySmartPlaylist: (payload: {
    name?: string;
    moods: MusicMood[];
    count: number;
    balanceMode: 'interleaved' | 'shuffled';
    startMode: 'replace_and_play' | 'append_queue';
    savePreset: boolean;
    customTracks?: Track[];
  }) => Promise<void>;
  onDeletePreset: (playlistId: string) => Promise<void>;
}

export const SmartPlaylistBuilder: React.FC<SmartPlaylistBuilderProps> = ({
  group,
  isBusy,
  onApplySmartPlaylist,
  onDeletePreset,
}) => {
  const [selectedMoods, setSelectedMoods] = useState<MusicMood[]>(['شاد', 'پاپ']);
  const [playlistName, setPlaylistName] = useState('');
  const [trackCount, setTrackCount] = useState<number>(20);
  const [balanceMode, setBalanceMode] = useState<'interleaved' | 'shuffled'>('interleaved');
  const [savePreset, setSavePreset] = useState<boolean>(true);

  const [previewTracks, setPreviewTracks] = useState<Track[]>([]);
  const [previewBreakdown, setPreviewBreakdown] = useState<Record<string, number>>({});
  const [previewLoading, setPreviewLoading] = useState(false);

  const toggleMood = (mood: MusicMood) => {
    setSelectedMoods((prev) => {
      if (prev.includes(mood)) {
        if (prev.length === 1) return prev; // Keep at least 1 mood selected
        return prev.filter((m) => m !== mood);
      }
      return [...prev, mood];
    });
  };

  const handleGeneratePreview = async () => {
    setPreviewLoading(true);
    try {
      const res = await fetch('/api/music/catalog/smart-playlist/preview', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          moods: selectedMoods,
          count: trackCount,
          balanceMode,
        }),
      });
      if (res.ok) {
        const data = (await res.json()) as {
          tracks?: Track[];
          breakdown?: Record<string, number>;
        };
        setPreviewTracks(data.tracks || []);
        setPreviewBreakdown(data.breakdown || {});
      }
    } finally {
      setPreviewLoading(false);
    }
  };

  const handleRemovePreviewTrack = (trackId: string) => {
    setPreviewTracks((prev) => prev.filter((t) => t.id !== trackId));
  };

  const handleApply = async (startMode: 'replace_and_play' | 'append_queue') => {
    const finalName = playlistName.trim() || `میکس هوشمند: ${selectedMoods.join(' + ')}`;
    await onApplySmartPlaylist({
      name: finalName,
      moods: selectedMoods,
      count: trackCount,
      balanceMode,
      startMode,
      savePreset,
      customTracks: previewTracks.length > 0 ? previewTracks : undefined,
    });
    setPreviewTracks([]);
  };

  const handleRunSavedPreset = async (preset: SmartPlaylistPreset) => {
    await onApplySmartPlaylist({
      name: preset.name,
      moods: preset.moods,
      count: preset.trackCount,
      balanceMode: preset.balanceMode,
      startMode: 'replace_and_play',
      savePreset: false,
    });
  };

  return (
    <section className="bg-[#111827] border border-slate-800 rounded-xl p-5 space-y-5">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-emerald-400" />
            <h3 className="text-base font-semibold text-slate-100">
              سازنده پلی‌لیست هوشمند ترکیبی (پخش متوالی در ویس‌چت)
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            چند سبک موسیقی را همزمان انتخاب کنید تا ربات یک ترکیب متعادل برای پخش خودکار و پشت‌سرهم در ویسکال گروه بسازد.
          </p>
        </div>

        <div className="text-xs text-slate-400 font-mono tabular-nums shrink-0">
          {selectedMoods.length} سبک انتخاب‌شده · {trackCount} آهنگ
        </div>
      </div>

      {/* Multi-select Genre Buttons */}
      <div className="space-y-2">
        <p className="text-xs text-slate-300 font-medium">انتخاب سبک‌های ترکیبی (حداقل ۱ یا چند سبک):</p>
        <div className="flex flex-wrap gap-2">
          {ALL_MOODS.map((mood) => {
            const active = selectedMoods.includes(mood);
            return (
              <button
                key={mood}
                type="button"
                onClick={() => toggleMood(mood)}
                className={`px-3.5 py-2 rounded-lg text-xs font-medium flex items-center gap-1.5 border transition-colors whitespace-nowrap cursor-pointer ${
                  active
                    ? 'bg-emerald-600/20 border-emerald-500 text-emerald-300'
                    : 'bg-[#0B0F17] border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                }`}
              >
                {active && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                <span>{mood}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Configuration Row */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
        <div className="md:col-span-5">
          <label className="block text-xs text-slate-400 mb-1.5">نام پلی‌لیست (اختیاری)</label>
          <input
            type="text"
            value={playlistName}
            onChange={(e) => setPlaylistName(e.target.value)}
            placeholder={`میکس هوشمند: ${selectedMoods.join(' + ')}`}
            className="w-full bg-[#0B0F17] border border-slate-800 focus:border-emerald-500 rounded-lg px-3 py-2 text-xs text-slate-100 placeholder:text-slate-500 outline-none"
          />
        </div>

        <div className="md:col-span-3">
          <label className="block text-xs text-slate-400 mb-1.5">تعداد آهنگ‌های ترکیب</label>
          <select
            value={trackCount}
            onChange={(e) => setTrackCount(Number(e.target.value))}
            className="w-full bg-[#0B0F17] border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 outline-none"
          >
            <option value={10}>۱۰ آهنگ متوالی</option>
            <option value={20}>۲۰ آهنگ متوالی</option>
            <option value={30}>۳۰ آهنگ متوالی</option>
            <option value={50}>۵۰ آهنگ متوالی</option>
          </select>
        </div>

        <div className="md:col-span-4">
          <label className="block text-xs text-slate-400 mb-1.5">الگوریتم چیدمان پخش</label>
          <div className="grid grid-cols-2 gap-1 p-1 bg-[#0B0F17] border border-slate-800 rounded-lg">
            <button
              type="button"
              onClick={() => setBalanceMode('interleaved')}
              className={`py-1.5 px-2 rounded text-xs font-medium transition-colors cursor-pointer ${
                balanceMode === 'interleaved'
                  ? 'bg-emerald-600 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              نوبتی متعادل
            </button>
            <button
              type="button"
              onClick={() => setBalanceMode('shuffled')}
              className={`py-1.5 px-2 rounded text-xs font-medium transition-colors cursor-pointer ${
                balanceMode === 'shuffled'
                  ? 'bg-emerald-600 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              تصادفی ترکیبی
            </button>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-slate-800/80">
        <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer select-none">
          <input
            type="checkbox"
            checked={savePreset}
            onChange={(e) => setSavePreset(e.target.checked)}
            className="accent-emerald-500 rounded cursor-pointer"
          />
          <span>ذخیره به عنوان پلی‌لیست آماده در گروه</span>
        </label>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            disabled={previewLoading}
            onClick={handleGeneratePreview}
            className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
          >
            {previewLoading ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Shuffle className="w-3.5 h-3.5 text-emerald-400" />
            )}
            <span>{previewTracks.length > 0 ? 'تغییر ترکیب پیش‌نمایش' : 'پیش‌نمایش لیست ترکیب'}</span>
          </button>

          <button
            type="button"
            disabled={isBusy}
            onClick={() => void handleApply('append_queue')}
            className="px-3.5 py-2 rounded-lg bg-[#0B0F17] hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
          >
            <ListPlus className="w-3.5 h-3.5 text-amber-400" />
            <span>افزودن به صف فعلی</span>
          </button>

          <button
            type="button"
            disabled={isBusy}
            onClick={() => void handleApply('replace_and_play')}
            className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
          >
            <Play className="w-3.5 h-3.5" />
            <span>ساخت و پخش متوالی در ویس‌چت</span>
          </button>
        </div>
      </div>

      {/* Generated Preview List */}
      {previewTracks.length > 0 && (
        <div className="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-800">
            <div className="text-xs text-slate-300">
              پیش‌نمایش ترکیب ({previewTracks.length} آهنگ):{' '}
              <span className="text-slate-400">
                {Object.entries(previewBreakdown)
                  .map(([m, c]) => `${m} (${c})`)
                  .join(' · ')}
              </span>
            </div>
            <button
              type="button"
              onClick={() => setPreviewTracks([])}
              className="text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
            >
              بستن پیش‌نمایش
            </button>
          </div>

          <div className="max-h-56 overflow-y-auto divide-y divide-slate-800/70">
            {previewTracks.map((t, idx) => (
              <div key={`${t.id}_${idx}`} className="py-2 flex items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2.5 min-w-0">
                  <span className="font-mono tabular-nums text-slate-500 w-5">{idx + 1}</span>
                  <span className="text-slate-100 font-medium truncate">{t.title}</span>
                  <span className="text-slate-400 truncate">· {t.artist}</span>
                  <span className="text-emerald-400 shrink-0">· {t.mood || 'پاپ'}</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleRemovePreviewTrack(t.id)}
                  className="text-slate-500 hover:text-red-400 cursor-pointer"
                  title="حذف از ترکیب"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Saved Smart Playlist Presets */}
      {(group.savedPlaylists?.length || 0) > 0 && (
        <div className="pt-4 border-t border-slate-800 space-y-2.5">
          <p className="text-xs font-semibold text-slate-300">پلی‌لیست‌های هوشمند ذخیره‌شده گروه</p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {group.savedPlaylists!.map((preset) => (
              <div
                key={preset.id}
                className="p-3 rounded-lg bg-[#0B0F17] border border-slate-800 flex items-center justify-between gap-3"
              >
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-slate-100 truncate">{preset.name}</p>
                  <p className="text-[11px] text-slate-400 truncate mt-0.5">
                    {preset.moods.join(' + ')} ·{' '}
                    <span className="font-mono tabular-nums">{preset.trackCount}</span> آهنگ
                  </p>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    disabled={isBusy}
                    onClick={() => void handleRunSavedPreset(preset)}
                    className="px-2.5 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium flex items-center gap-1 cursor-pointer"
                  >
                    <Play className="w-3 h-3" />
                    <span>پخش</span>
                  </button>
                  <button
                    type="button"
                    disabled={isBusy}
                    onClick={() => void onDeletePreset(preset.id)}
                    className="p-1.5 rounded bg-slate-800 hover:bg-red-500/20 text-slate-400 hover:text-red-400 cursor-pointer"
                    aria-label="حذف پلی‌لیست ذخیره‌شده"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </section>
  );
};
