import React, {useEffect, useState} from 'react';
import {
  Clock,
  Disc3,
  ExternalLink,
  Globe,
  History,
  Link2,
  ListMusic,
  Mic,
  MicOff,
  Pause,
  PhoneCall,
  PhoneOff,
  Play,
  Plus,
  RefreshCw,
  Search,
  Shuffle,
  SkipBack,
  SkipForward,
  Trash2,
  TrendingUp,
  Volume2,
  VolumeX,
  Zap,
} from 'lucide-react';
import {GroupState, MusicMood, Track} from '../types/bot';
import {MusicCatalogPanel} from './MusicCatalogPanel';
import {SmartPlaylistBuilder} from './SmartPlaylistBuilder';

interface VoiceCallStudioViewProps {
  group: GroupState;
  isBusy: boolean;
  audioState: {
    currentTime: number;
    duration: number;
    frequencyBars: number[];
    audioError: string | null;
    isBuffering: boolean;
    micActive: boolean;
    micError: string | null;
    seekTo: (sec: number) => void;
    toggleMic: () => void;
    unlockAudioAndPlay: () => void;
  };
  onRunCommand: (text: string) => Promise<void>;
  onSelectTrack: (track: Track, mode: 'play_now' | 'queue') => Promise<void>;
  onEnqueueMood: (mood: MusicMood, count: number) => Promise<void>;
  onSetAutoShutdown: (payload: {
    enabled: boolean;
    targetTime: string;
    stopPollingAlso: boolean;
  }) => Promise<void>;
  onApplySmartPlaylist: (payload: {
    name?: string;
    moods: MusicMood[];
    count: number;
    balanceMode: 'interleaved' | 'shuffled';
    startMode: 'replace_and_play' | 'append_queue';
    savePreset: boolean;
    customTracks?: Track[];
  }) => Promise<void>;
  onDeletePreset: (playlistId: string) => Promise<void>;
}

function formatSec(sec: number): string {
  if (!Number.isFinite(sec) || sec <= 0) return '00:00';
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export const VoiceCallStudioView: React.FC<VoiceCallStudioViewProps> = ({
  group,
  isBusy,
  audioState,
  onRunCommand,
  onSelectTrack,
  onEnqueueMood,
  onSetAutoShutdown,
  onApplySmartPlaylist,
  onDeletePreset,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Track[]>([]);
  const [searching, setSearching] = useState(false);
  const [searchNotice, setSearchNotice] = useState<string | null>(null);
  const [directUrl, setDirectUrl] = useState('');
  const [volumeDraft, setVolumeDraft] = useState<number | null>(null);
  const [shutdownTime, setShutdownTime] = useState<string>(group.autoShutdown?.targetTime || '23:30');
  const [stopPollingAlso, setStopPollingAlso] = useState<boolean>(
    Boolean(group.autoShutdown?.stopPollingAlso),
  );
  const [countdownText, setCountdownText] = useState<string>('');
  const [trendingLoading, setTrendingLoading] = useState(false);
  const [trendingError, setTrendingError] = useState<string | null>(null);
  const [trendingResult, setTrendingResult] = useState<{
    suggestions: Array<{rank: number; reason?: string; track: Track}>;
    sources: Array<{title: string; uri: string}>;
    provider: string;
    notice?: string;
    searchedAt: string;
  } | null>(null);

  const handleDiscoverTrending = async () => {
    setTrendingLoading(true);
    setTrendingError(null);
    try {
      const res = await fetch('/api/music/trending-rubika', {method: 'POST'});
      const data = await res.json();
      if (!res.ok) {
        setTrendingError(data.error || 'خطا در جستجوی آنلاین آهنگ‌های محبوب روز روبیکا.');
      } else {
        setTrendingResult(data);
      }
    } catch {
      setTrendingError('عدم دسترسی به سرویس جستجوی آنلاین.');
    } finally {
      setTrendingLoading(false);
    }
  };

  useEffect(() => {
    if (group.autoShutdown?.targetTime) {
      setShutdownTime(group.autoShutdown.targetTime);
      setStopPollingAlso(Boolean(group.autoShutdown.stopPollingAlso));
    }
  }, [group.autoShutdown?.targetTime, group.autoShutdown?.stopPollingAlso]);

  useEffect(() => {
    const nextIso = group.autoShutdown?.enabled ? group.autoShutdown.nextTriggerIso : null;
    if (!nextIso) {
      setCountdownText('');
      return;
    }
    const updateTimer = () => {
      const diffMs = Math.max(0, new Date(nextIso).getTime() - Date.now());
      const totalSec = Math.floor(diffMs / 1000);
      const h = Math.floor(totalSec / 3600);
      const m = Math.floor((totalSec % 3600) / 60);
      const s = totalSec % 60;
      setCountdownText(
        `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`,
      );
    };
    updateTimer();
    const id = setInterval(updateTimer, 1000);
    return () => clearInterval(id);
  }, [group.autoShutdown?.enabled, group.autoShutdown?.nextTriggerIso]);

  const setOffsetMinutes = (mins: number) => {
    const target = new Date(Date.now() + mins * 60 * 1000);
    const hh = String(target.getHours()).padStart(2, '0');
    const mm = String(target.getMinutes()).padStart(2, '0');
    setShutdownTime(`${hh}:${mm}`);
  };

  const displayedVolume = volumeDraft ?? group.volume;

  const handleMusicSearch = async (queryOverride?: string) => {
    const q = (queryOverride ?? searchQuery).trim();
    if (!q) return;
    setSearching(true);
    setSearchNotice(null);
    try {
      const res = await fetch(`/api/music/search?q=${encodeURIComponent(q)}`);
      const data = (await res.json()) as {tracks?: Track[]};
      const found = data.tracks || [];
      setSearchResults(found);
      if (found.length === 0) {
        setSearchNotice(`نتیجه‌ای برای «${q}» یافت نشد. عبارت دیگری جستجو کنید یا لینک مستقیم وارد نمایید.`);
      }
    } catch {
      setSearchNotice('خطا در اتصال به سرویس جستجوی موسیقی.');
    } finally {
      setSearching(false);
    }
  };

  const handleDirectAction = async (mode: 'play' | 'instant' | 'queue') => {
    const cleaned = directUrl.trim();
    if (!cleaned) return;
    const prefix =
      mode === 'instant' ? 'پخش فوری' : mode === 'queue' ? 'اضافه به صف' : 'پخش ویسکال';
    await onRunCommand(`${prefix} ${cleaned}`);
    setDirectUrl('');
  };

  const activeArt = group.currentTrack?.artworkUrl || '/src/assets/images/voice_room_cover_1794902868085.jpg';

  return (
    <div className="space-y-6">
      {/* Main Voice Call & Active Player Deck */}
      <section className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
          {/* Visual Cover & FFT Audio Spectrum */}
          <div className="lg:col-span-5 relative min-h-[240px] bg-[#0B0F17] flex flex-col justify-between p-5 border-b lg:border-b-0 lg:border-l border-slate-800 overflow-hidden">
            <img
              src={activeArt}
              alt={group.currentTrack?.title || 'استودیو ویسکال روبیکا'}
              referrerPolicy="no-referrer"
              className="absolute inset-0 w-full h-full object-cover opacity-35"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0B0F17] via-[#0B0F17]/70 to-[#0B0F17]/40" />

            <div className="relative z-10 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-xs text-slate-300">
                <span
                  className={`inline-block w-2 h-2 rounded-full ${
                    group.voiceCallActive ? 'bg-emerald-500' : 'bg-slate-500'
                  }`}
                />
                <span>{group.voiceCallActive ? 'ویس‌چت گروهی فعال' : 'ویس‌چت غیرفعال'}</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono tabular-nums">{group.rubikaChatId}</span>
              </div>
              {group.isMuted && (
                <span className="text-xs font-medium text-amber-400">بیصدا (پخش در پس‌زمینه)</span>
              )}
            </div>

            {/* Live FFT Spectrum Bars */}
            <div className="relative z-10 my-6 flex items-end justify-center gap-1.5 h-20">
              {audioState.frequencyBars.map((val, idx) => (
                <div
                  key={idx}
                  style={{height: `${val}%`}}
                  className={`w-2 rounded-t transition-all duration-75 ${
                    group.isMuted
                      ? 'bg-amber-500/45'
                      : group.isPlaying
                        ? 'bg-emerald-500'
                        : 'bg-slate-700'
                  }`}
                />
              ))}
            </div>

            <div className="relative z-10 flex items-center justify-between gap-2 text-xs text-slate-300">
              <span className="truncate">
                {group.currentTrack
                  ? `درخواست‌کننده: ${group.currentTrack.requestedBy}`
                  : 'آماده دریافت دستور پخش در گروه'}
              </span>
              <span className="font-mono tabular-nums shrink-0">
                {formatSec(audioState.currentTime)} / {formatSec(audioState.duration || group.currentTrack?.durationSec || 0)}
              </span>
            </div>
          </div>

          {/* Controls & Mixer */}
          <div className="lg:col-span-7 p-6 flex flex-col justify-between gap-5">
            <div>
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="min-w-0">
                  <p className="text-xs text-slate-400 mb-1">
                    {group.title} · {group.publicAccess === 'open' ? 'دسترسی عموم باز' : 'دسترسی قفل'}
                  </p>
                  <h2 className="text-xl font-bold text-slate-100 truncate">
                    {group.currentTrack
                      ? group.currentTrack.title
                      : group.pausedTrack
                        ? `متوقف‌شده: ${group.pausedTrack.title}`
                        : 'هیچ آهنگی در حال پخش نیست'}
                  </h2>
                  <p className="text-sm text-slate-400 mt-1 truncate">
                    {group.currentTrack
                      ? `${group.currentTrack.artist} · منبع: ${group.currentTrack.source === 'itunes' ? 'جستجوی زنده' : group.currentTrack.source === 'deezer' ? 'دیزر' : 'لینک مستقیم'}`
                      : 'یک آهنگ جستجو کنید یا دستور «آهنگ لری» را اجرا نمایید'}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  <button
                    type="button"
                    disabled={trendingLoading}
                    onClick={handleDiscoverTrending}
                    className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-emerald-300 text-xs font-medium flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    {trendingLoading ? (
                      <RefreshCw className="w-4 h-4 animate-spin" />
                    ) : (
                      <TrendingUp className="w-4 h-4" />
                    )}
                    <span>{trendingLoading ? 'جستجوی آنلاین ترندها...' : 'محبوب‌ترین‌های روز روبیکا'}</span>
                  </button>

                  <button
                    type="button"
                    disabled={isBusy}
                    onClick={() => onRunCommand(group.voiceCallActive ? 'قطع ویسکال' : 'ساخت کال')}
                    className={`px-3.5 py-2 rounded-lg text-xs font-medium flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                      group.voiceCallActive
                        ? 'bg-red-500/15 text-red-400 border border-red-500/30 hover:bg-red-500/25'
                        : 'bg-emerald-600 text-white hover:bg-emerald-500'
                    }`}
                  >
                    {group.voiceCallActive ? <PhoneOff className="w-4 h-4" /> : <PhoneCall className="w-4 h-4" />}
                    <span>{group.voiceCallActive ? 'قطع ویسکال' : 'ساخت کال'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={audioState.toggleMic}
                    className={`px-3.5 py-2 rounded-lg text-xs font-medium flex items-center gap-2 border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                      audioState.micActive
                        ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40'
                        : 'bg-slate-800/70 text-slate-300 border-slate-700 hover:bg-slate-800'
                    }`}
                  >
                    {audioState.micActive ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
                    <span>{audioState.micActive ? 'میکروفون متصل' : 'میکروفون کال'}</span>
                  </button>
                </div>
              </div>

              {/* Scrubber */}
              <div className="mt-5">
                <input
                  type="range"
                  min={0}
                  max={Math.max(1, audioState.duration || group.currentTrack?.durationSec || 30)}
                  value={Math.min(
                    audioState.currentTime,
                    audioState.duration || group.currentTrack?.durationSec || 30,
                  )}
                  onChange={(e) => audioState.seekTo(Number(e.target.value))}
                  disabled={!group.currentTrack}
                  aria-label="موقعیت پخش آهنگ"
                  className="w-full accent-emerald-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                />
              </div>

              {(audioState.audioError || audioState.micError) && (
                <div className="mt-3 p-3 rounded-lg bg-amber-500/10 border border-amber-500/30 text-xs text-amber-300 flex items-center justify-between gap-3">
                  <span>{audioState.audioError || audioState.micError}</span>
                  {audioState.audioError && (
                    <button
                      type="button"
                      onClick={audioState.unlockAudioAndPlay}
                      className="px-2.5 py-1 bg-amber-500 text-slate-950 font-semibold rounded text-xs whitespace-nowrap cursor-pointer"
                    >
                      تلاش مجدد پخش
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* Playback & Volume Controls */}
            <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-slate-800/80">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  disabled={isBusy}
                  onClick={() => onRunCommand('قبلی')}
                  className="px-3 py-2 rounded-lg bg-slate-800/80 hover:bg-slate-800 text-slate-200 text-xs font-medium flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
                >
                  <SkipForward className="w-4 h-4" />
                  <span>قبلی</span>
                </button>

                {group.isPlaying ? (
                  <button
                    type="button"
                    disabled={isBusy}
                    onClick={() => onRunCommand('توقف آهنگ')}
                    className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
                  >
                    <Pause className="w-4 h-4" />
                    <span>توقف و ذخیره</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    disabled={isBusy || (!group.pausedTrack && !group.currentTrack)}
                    onClick={() => {
                      if (group.pausedTrack) {
                        void onRunCommand('ادامه آهنگ');
                      } else {
                        audioState.unlockAudioAndPlay();
                      }
                    }}
                    className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white text-xs font-bold flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
                  >
                    <Play className="w-4 h-4" />
                    <span>ادامه آهنگ</span>
                  </button>
                )}

                <button
                  type="button"
                  disabled={isBusy}
                  onClick={() => onRunCommand('بعدی')}
                  className="px-3 py-2 rounded-lg bg-slate-800/80 hover:bg-slate-800 text-slate-200 text-xs font-medium flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
                >
                  <SkipBack className="w-4 h-4" />
                  <span>بعدی</span>
                </button>

                <button
                  type="button"
                  disabled={isBusy}
                  onClick={() => onRunCommand('پخش رندوم')}
                  className="px-3 py-2 rounded-lg bg-slate-800/80 hover:bg-slate-800 text-slate-200 text-xs font-medium flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
                >
                  <Shuffle className="w-4 h-4" />
                  <span>پخش رندوم</span>
                </button>
              </div>

              {/* Volume & Mute / Unmute */}
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  disabled={isBusy}
                  onClick={() => onRunCommand(group.isMuted ? 'باصدا' : 'بیصدا')}
                  className={`px-3 py-2 rounded-lg text-xs font-medium flex items-center gap-1.5 border whitespace-nowrap cursor-pointer ${
                    group.isMuted
                      ? 'bg-amber-500/15 text-amber-300 border-amber-500/30 hover:bg-amber-500/25'
                      : 'bg-slate-800/80 text-slate-200 border-slate-700 hover:bg-slate-800'
                  }`}
                >
                  {group.isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                  <span>{group.isMuted ? 'باصدا کن' : 'بیصدا'}</span>
                </button>

                <div className="flex items-center gap-2 min-w-[140px]">
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={displayedVolume}
                    onChange={(e) => setVolumeDraft(Number(e.target.value))}
                    onMouseUp={() => {
                      if (volumeDraft !== null) {
                        void onRunCommand(`تنظیم صدا ${volumeDraft}`);
                        setVolumeDraft(null);
                      }
                    }}
                    onTouchEnd={() => {
                      if (volumeDraft !== null) {
                        void onRunCommand(`تنظیم صدا ${volumeDraft}`);
                        setVolumeDraft(null);
                      }
                    }}
                    aria-label="تنظیم صدا"
                    className="w-24 accent-emerald-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                  />
                  <span className="font-mono tabular-nums text-xs text-slate-300 w-9 text-left">
                    {displayedVolume}%
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Online Trending Rubika Songs Suggestions */}
      {(trendingError || trendingResult) && (
        <section className="bg-[#111827] border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-emerald-400" />
              <h3 className="text-base font-semibold text-slate-100">
                پیشنهاد آنلاین محبوب‌ترین آهنگ‌های روز روبیکا
              </h3>
              {trendingResult && (
                <span className="text-xs text-slate-400 font-mono tabular-nums">
                  · {trendingResult.suggestions.length} آهنگ ·{' '}
                  {new Date(trendingResult.searchedAt).toLocaleTimeString('fa-IR')}
                </span>
              )}
            </div>

            <div className="flex items-center gap-2">
              {trendingResult && trendingResult.suggestions.length > 0 && (
                <button
                  type="button"
                  disabled={isBusy}
                  onClick={() =>
                    void onApplySmartPlaylist({
                      name: 'محبوب‌ترین‌های روز روبیکا',
                      moods: ['شاد', 'پاپ'],
                      count: trendingResult.suggestions.length,
                      balanceMode: 'interleaved',
                      startMode: 'replace_and_play',
                      savePreset: false,
                      customTracks: trendingResult.suggestions.map((s) => s.track),
                    })
                  }
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>پخش متوالی همه در ویسکال</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => {
                  setTrendingResult(null);
                  setTrendingError(null);
                }}
                className="px-2.5 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 cursor-pointer"
              >
                بستن
              </button>
            </div>
          </div>

          {trendingError && (
            <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-300">
              {trendingError}
            </div>
          )}

          {trendingResult?.notice && (
            <p className="text-xs text-amber-400">{trendingResult.notice}</p>
          )}

          {trendingResult && trendingResult.suggestions.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {trendingResult.suggestions.map((item) => (
                <div
                  key={`${item.track.id}_${item.rank}`}
                  className="p-3 rounded-lg bg-[#0B0F17] border border-slate-800 flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <span className="font-mono tabular-nums text-xs font-bold text-emerald-400 w-5 shrink-0">
                      #{item.rank}
                    </span>
                    {item.track.artworkUrl ? (
                      <img
                        src={item.track.artworkUrl}
                        alt={item.track.title}
                        referrerPolicy="no-referrer"
                        className="w-10 h-10 rounded object-cover shrink-0 border border-slate-800"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded bg-slate-800 flex items-center justify-center shrink-0">
                        <Disc3 className="w-4 h-4 text-slate-400" />
                      </div>
                    )}
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-slate-100 truncate">
                        {item.track.title}
                      </p>
                      <p className="text-[11px] text-slate-400 truncate">
                        {item.track.artist}
                        {item.reason ? ` · ${item.reason}` : ''}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      disabled={isBusy}
                      onClick={() => onSelectTrack(item.track, 'play_now')}
                      className="p-2 rounded bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer"
                      title="پخش فوری در ویسکال"
                      aria-label="پخش فوری"
                    >
                      <Zap className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      disabled={isBusy}
                      onClick={() => onSelectTrack(item.track, 'queue')}
                      className="p-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer"
                      title="افزودن به صف"
                      aria-label="افزودن به صف"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {trendingResult && trendingResult.sources.length > 0 && (
            <div className="pt-3 border-t border-slate-800 flex flex-wrap items-center gap-3 text-[11px] text-slate-400">
              <span>منابع جستجوی آنلاین:</span>
              {trendingResult.sources.map((src, i) => (
                <a
                  key={`${src.uri}_${i}`}
                  href={src.uri}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-emerald-400 hover:underline flex items-center gap-1"
                >
                  <span className="truncate max-w-[200px]">{src.title}</span>
                  <ExternalLink className="w-3 h-3 shrink-0" />
                </a>
              ))}
            </div>
          )}
        </section>
      )}

      {/* Auto-Shutdown Schedule Card */}
      <section className="bg-[#111827] border border-slate-800 rounded-xl p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-5">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-semibold text-slate-100">
              تایمر قطع خودکار ویسکال (خاموشی ربات در ساعت مشخص)
            </h3>
            {group.autoShutdown?.enabled && countdownText && (
              <span className="text-xs font-mono tabular-nums text-emerald-400">
                · فعال ({group.autoShutdown.targetTime} · باقیمانده {countdownText})
              </span>
            )}
          </div>
          <p className="text-xs text-slate-400">
            با رسیدن به ساعت تعیین‌شده، پخش موسیقی و ویس‌چت گروه به صورت خودکار قطع می‌شود (یا با دستور «تنظیم خاموشی 23:30» در چت گروه).
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <div className="flex items-center gap-1.5">
            {[
              {label: '+۳۰ دقیقه', mins: 30},
              {label: '+۱ ساعت', mins: 60},
              {label: '+۲ ساعت', mins: 120},
            ].map((p) => (
              <button
                key={p.mins}
                type="button"
                onClick={() => setOffsetMinutes(p.mins)}
                className="px-2.5 py-1.5 rounded bg-[#0B0F17] hover:bg-slate-800 border border-slate-800 text-xs text-slate-300 whitespace-nowrap cursor-pointer"
              >
                {p.label}
              </button>
            ))}
          </div>

          <input
            type="time"
            dir="ltr"
            value={shutdownTime}
            onChange={(e) => setShutdownTime(e.target.value)}
            aria-label="ساعت خاموشی خودکار"
            className="bg-[#0B0F17] border border-slate-800 focus:border-emerald-500 rounded-lg px-3 py-1.5 text-sm font-mono text-slate-100 outline-none"
          />

          <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={stopPollingAlso}
              onChange={(e) => setStopPollingAlso(e.target.checked)}
              className="accent-emerald-500 rounded cursor-pointer"
            />
            <span>خاموشی کامل ربات</span>
          </label>

          <button
            type="button"
            disabled={isBusy || !shutdownTime}
            onClick={() =>
              onSetAutoShutdown({
                enabled: true,
                targetTime: shutdownTime,
                stopPollingAlso,
              })
            }
            className="px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white text-xs font-medium whitespace-nowrap cursor-pointer"
          >
            {group.autoShutdown?.enabled ? 'بروزرسانی ساعت خاموشی' : 'تنظیم خاموشی خودکار'}
          </button>

          {group.autoShutdown?.enabled && (
            <button
              type="button"
              disabled={isBusy}
              onClick={() =>
                onSetAutoShutdown({
                  enabled: false,
                  targetTime: shutdownTime,
                  stopPollingAlso,
                })
              }
              className="px-3 py-2 rounded-lg bg-red-500/15 hover:bg-red-500/25 text-red-400 border border-red-500/30 text-xs font-medium whitespace-nowrap cursor-pointer"
            >
              لغو تایمر
            </button>
          )}
        </div>
      </section>

      {/* Real Music Search & Direct Link Player */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 bg-[#111827] border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-semibold text-slate-100">جستجوی واقعی آهنگ</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                معادل دستور «آهنگ &#123;نام موسیقی&#125;» با دریافت جریان صوتی واقعی
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-1.5">
              {['آهنگ لری', 'شادمهر عقیلی', 'محسن چاوشی', 'هایده'].map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => {
                    setSearchQuery(preset);
                    void handleMusicSearch(preset);
                  }}
                  className="px-2.5 py-1 rounded bg-slate-800/80 hover:bg-slate-700 text-xs text-slate-300 whitespace-nowrap cursor-pointer"
                >
                  {preset}
                </button>
              ))}
            </div>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              void handleMusicSearch();
            }}
            className="flex items-center gap-2"
          >
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-500 absolute right-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="نام آهنگ یا خواننده را بنویسید (مثلاً: آهنگ لری)..."
                className="w-full bg-[#0B0F17] border border-slate-800 focus:border-emerald-500 rounded-lg pr-9 pl-3 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 outline-none"
              />
            </div>
            <button
              type="submit"
              disabled={searching || !searchQuery.trim()}
              className="px-4 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-sm font-medium whitespace-nowrap cursor-pointer"
            >
              {searching ? 'در حال جستجو...' : 'جستجو'}
            </button>
          </form>

          {searchNotice && <p className="text-xs text-amber-400">{searchNotice}</p>}

          {searchResults.length > 0 ? (
            <div className="divide-y divide-slate-800/80 max-h-[340px] overflow-y-auto">
              {searchResults.map((track) => (
                <div
                  key={track.id}
                  className="py-2.5 flex items-center justify-between gap-3 hover:bg-slate-800/30 px-2 rounded-lg transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    {track.artworkUrl ? (
                      <img
                        src={track.artworkUrl}
                        alt={track.title}
                        referrerPolicy="no-referrer"
                        className="w-10 h-10 rounded object-cover shrink-0 border border-slate-800"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded bg-slate-800 flex items-center justify-center shrink-0">
                        <Disc3 className="w-5 h-5 text-slate-400" />
                      </div>
                    )}
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-slate-100 truncate">{track.title}</p>
                      <p className="text-xs text-slate-400 truncate">
                        {track.artist} · <span className="font-mono tabular-nums">{formatSec(track.durationSec)}</span>
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => onSelectTrack(track, 'play_now')}
                      className="px-2.5 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium flex items-center gap-1 whitespace-nowrap cursor-pointer"
                    >
                      <Zap className="w-3.5 h-3.5" />
                      <span>پخش فوری</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onSelectTrack(track, 'queue')}
                      className="px-2.5 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1 whitespace-nowrap cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>به صف</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-8 text-center border border-dashed border-slate-800 rounded-lg">
              <p className="text-sm text-slate-400">
                برای دریافت فایل‌های صوتی قابل پخش در ویسکال، نام یک موسیقی را جستجو کنید.
              </p>
            </div>
          )}
        </div>

        {/* Direct Link Streaming */}
        <div className="lg:col-span-5 bg-[#111827] border border-slate-800 rounded-xl p-5 flex flex-col justify-between gap-4">
          <div className="space-y-4">
            <div>
              <h3 className="text-base font-semibold text-slate-100">پخش از لینک مستقیم صوتی</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                پشتیبانی از «پخش ویسکال &#123;لینک&#125;»، «پخش فوری» و «اضافه به صف»
              </p>
            </div>

            <div className="relative">
              <Link2 className="w-4 h-4 text-slate-500 absolute right-3 top-1/2 -translate-y-1/2" />
              <input
                type="url"
                dir="ltr"
                value={directUrl}
                onChange={(e) => setDirectUrl(e.target.value)}
                placeholder="https://example.com/song.mp3"
                className="w-full bg-[#0B0F17] border border-slate-800 focus:border-emerald-500 rounded-lg pr-9 pl-3 py-2.5 text-sm font-mono text-slate-100 placeholder:text-slate-600 outline-none text-left"
              />
            </div>

            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                disabled={isBusy || !directUrl.trim()}
                onClick={() => handleDirectAction('play')}
                className="py-2 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white text-xs font-medium whitespace-nowrap cursor-pointer"
              >
                پخش ویسکال
              </button>
              <button
                type="button"
                disabled={isBusy || !directUrl.trim()}
                onClick={() => handleDirectAction('instant')}
                className="py-2 px-3 rounded-lg bg-amber-500 hover:bg-amber-400 disabled:opacity-40 text-slate-950 text-xs font-semibold whitespace-nowrap cursor-pointer"
              >
                پخش فوری
              </button>
              <button
                type="button"
                disabled={isBusy || !directUrl.trim()}
                onClick={() => handleDirectAction('queue')}
                className="py-2 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 text-xs font-medium whitespace-nowrap cursor-pointer"
              >
                اضافه به صف
              </button>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 text-xs text-slate-400 space-y-1.5">
            <p className="text-slate-300 font-medium">نکته فنی پخش زنده ویسکال:</p>
            <p>
              تمامی جریان‌های صوتی از مسیر پراکسی سرور داخلی ربات عبور می‌کنند تا کنترل دقیق ولوم، حالت بی‌صدا با تداوم پخش و تحلیل فرکانس بدون خطای CORS انجام شود.
            </p>
          </div>
        </div>
      </section>

      {/* Queue & History Tables */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Queue */}
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <ListMusic className="w-4 h-4 text-emerald-400" />
              <h3 className="text-base font-semibold text-slate-100">صف پخش گروه</h3>
              <span className="text-xs text-slate-400 font-mono tabular-nums">({group.queue.length})</span>
            </div>
            <button
              type="button"
              disabled={isBusy || group.queue.length === 0}
              onClick={() => onRunCommand('پاک کردن صف')}
              className="px-2.5 py-1.5 rounded bg-red-500/10 hover:bg-red-500/20 disabled:opacity-40 text-red-400 text-xs font-medium flex items-center gap-1 whitespace-nowrap cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>پاک کردن صف</span>
            </button>
          </div>

          {group.queue.length === 0 ? (
            <div className="py-8 text-center border border-dashed border-slate-800 rounded-lg text-xs text-slate-400">
              صف پخش خالی است. از بخش جستجو یا دستور «اضافه به صف» آهنگ اضافه کنید.
            </div>
          ) : (
            <div className="divide-y divide-slate-800/80">
              {group.queue.map((item, index) => (
                <div key={`${item.id}_${index}`} className="py-2.5 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <span className="font-mono tabular-nums text-xs text-slate-500 w-5">{index + 1}</span>
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-slate-100 truncate">{item.title}</p>
                      <p className="text-xs text-slate-400 truncate">
                        {item.artist} · درخواست: {item.requestedBy}
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    disabled={isBusy}
                    onClick={() => onRunCommand(`حذف از صف ${index + 1}`)}
                    className="px-2 py-1 rounded text-xs text-red-400 hover:bg-red-500/15 whitespace-nowrap cursor-pointer"
                  >
                    حذف
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* History (last 5) */}
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <History className="w-4 h-4 text-slate-400" />
              <h3 className="text-base font-semibold text-slate-100">تاریخچه آهنگ‌ها (۵ مورد آخر)</h3>
            </div>
            <button
              type="button"
              disabled={isBusy}
              onClick={() => onRunCommand('تاریخچه آهنگها')}
              className="px-2.5 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium whitespace-nowrap cursor-pointer"
            >
              ارسال در چت گروه
            </button>
          </div>

          {group.history.length === 0 ? (
            <div className="py-8 text-center border border-dashed border-slate-800 rounded-lg text-xs text-slate-400">
              هنوز آهنگی به پایان نرسیده یا تعویض نشده است.
            </div>
          ) : (
            <div className="divide-y divide-slate-800/80">
              {group.history
                .slice(-5)
                .reverse()
                .map((item, idx) => (
                  <div key={`${item.id}_hist_${idx}`} className="py-2.5 flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-slate-100 truncate">{item.title}</p>
                      <p className="text-xs text-slate-400 truncate">
                        {item.artist} · {new Date(item.requestedAt).toLocaleTimeString('fa-IR')}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => onSelectTrack(item, 'play_now')}
                      className="px-2.5 py-1.5 rounded bg-slate-800 hover:bg-emerald-600 text-slate-200 hover:text-white text-xs font-medium whitespace-nowrap cursor-pointer"
                    >
                      پخش مجدد
                    </button>
                  </div>
                ))}
            </div>
          )}
        </div>
      </section>

      {/* Smart Multi-Genre Playlist Builder */}
      <SmartPlaylistBuilder
        group={group}
        isBusy={isBusy}
        onApplySmartPlaylist={onApplySmartPlaylist}
        onDeletePreset={onDeletePreset}
      />

      {/* 1,000+ Categorized Music Archive (شاد / غمگین / پاپ / سنتی / محلی) */}
      <MusicCatalogPanel
        isBusy={isBusy}
        onSelectTrack={onSelectTrack}
        onRunCommand={onRunCommand}
        onEnqueueMood={onEnqueueMood}
      />
    </div>
  );
};
