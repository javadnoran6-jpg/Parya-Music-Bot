import {useCallback, useEffect, useRef, useState} from 'react';
import {Track} from '../types/bot';

interface UseVoiceAudioEngineOptions {
  currentTrack: Track | null;
  isPlaying: boolean;
  isMuted: boolean;
  volume: number;
  voiceCallActive: boolean;
  onTrackEnded: () => void;
}

export function useVoiceAudioEngine({
  currentTrack,
  isPlaying,
  isMuted,
  volume,
  voiceCallActive,
  onTrackEnded,
}: UseVoiceAudioEngineOptions) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const sourceNodeRef = useRef<MediaElementAudioSourceNode | null>(null);
  const micStreamRef = useRef<MediaStream | null>(null);
  const micSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);

  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [frequencyBars, setFrequencyBars] = useState<number[]>(() => Array(20).fill(6));
  const [audioError, setAudioError] = useState<string | null>(null);
  const [isBuffering, setIsBuffering] = useState(false);
  const [micActive, setMicActive] = useState(false);
  const [micError, setMicError] = useState<string | null>(null);

  const lastLoadedTrackIdRef = useRef<string | null>(null);
  const onEndedRef = useRef(onTrackEnded);
  onEndedRef.current = onTrackEnded;

  const ensureAudioGraph = useCallback(() => {
    if (!audioRef.current) return;
    if (!audioCtxRef.current) {
      const Ctx = window.AudioContext || (window as unknown as {webkitAudioContext: typeof AudioContext}).webkitAudioContext;
      const ctx = new Ctx();
      const gain = ctx.createGain();
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 64;
      analyser.smoothingTimeConstant = 0.78;

      const source = ctx.createMediaElementSource(audioRef.current);
      source.connect(gain);
      gain.connect(analyser);
      analyser.connect(ctx.destination);

      audioCtxRef.current = ctx;
      gainNodeRef.current = gain;
      analyserRef.current = analyser;
      sourceNodeRef.current = source;
    }
    if (audioCtxRef.current.state === 'suspended') {
      void audioCtxRef.current.resume();
    }
  }, []);

  // Create persistent audio element once
  useEffect(() => {
    const audio = new Audio();
    audio.crossOrigin = 'anonymous';
    audio.preload = 'auto';
    audioRef.current = audio;

    const handleTimeUpdate = () => setCurrentTime(audio.currentTime || 0);
    const handleLoadedMetadata = () => {
      setDuration(Number.isFinite(audio.duration) ? audio.duration : 0);
      setIsBuffering(false);
      setAudioError(null);
    };
    const handleWaiting = () => setIsBuffering(true);
    const handleCanPlay = () => setIsBuffering(false);
    const handleEnded = () => onEndedRef.current();
    const handleError = () => {
      setIsBuffering(false);
      setAudioError('خطا در بارگذاری جریان صوتی این لینک. لینک دیگری امتحان کنید.');
    };

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('waiting', handleWaiting);
    audio.addEventListener('canplay', handleCanPlay);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('error', handleError);

    return () => {
      audio.pause();
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('waiting', handleWaiting);
      audio.removeEventListener('canplay', handleCanPlay);
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('error', handleError);
      if (micStreamRef.current) {
        micStreamRef.current.getTracks().forEach((t) => t.stop());
      }
      if (audioCtxRef.current) {
        void audioCtxRef.current.close();
      }
    };
  }, []);

  // Sync GainNode volume and mute (بیصدا keeps track playing with gain=0)
  useEffect(() => {
    const targetGain = isMuted ? 0 : Math.max(0, Math.min(1, volume / 100));
    if (gainNodeRef.current && audioCtxRef.current) {
      gainNodeRef.current.gain.setTargetAtTime(targetGain, audioCtxRef.current.currentTime, 0.04);
    }
    if (audioRef.current) {
      // If AudioContext isn't unlocked yet, still apply muted/volume cleanly
      if (!sourceNodeRef.current) {
        audioRef.current.muted = isMuted;
        audioRef.current.volume = Math.max(0, Math.min(1, volume / 100));
      } else {
        audioRef.current.muted = false;
        audioRef.current.volume = 1;
      }
    }
  }, [isMuted, volume]);

  // Load track and control play/pause
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    if (!currentTrack) {
      audio.pause();
      audio.removeAttribute('src');
      lastLoadedTrackIdRef.current = null;
      setCurrentTime(0);
      setDuration(0);
      setAudioError(null);
      return;
    }

    const proxiedUrl = `/api/music/stream?url=${encodeURIComponent(currentTrack.streamUrl)}`;
    if (lastLoadedTrackIdRef.current !== currentTrack.id) {
      lastLoadedTrackIdRef.current = currentTrack.id;
      setAudioError(null);
      setIsBuffering(true);
      audio.src = proxiedUrl;
      audio.load();
    }

    if (isPlaying) {
      ensureAudioGraph();
      audio.play().catch(() => {
        setIsBuffering(false);
        setAudioError('برای شروع پخش صدا در مرورگر روی دکمه ادامه پخش کلیک کنید.');
      });
    } else {
      audio.pause();
    }
  }, [currentTrack, isPlaying, ensureAudioGraph]);

  // Real-time FFT Spectrum Visualizer loop
  useEffect(() => {
    let rafId = 0;
    const dataArray = new Uint8Array(32);

    const updateBars = () => {
      if (analyserRef.current && isPlaying) {
        analyserRef.current.getByteFrequencyData(dataArray);
        const bars: number[] = [];
        for (let i = 0; i < 20; i++) {
          const val = dataArray[i] || 0;
          const pct = Math.max(8, Math.round((val / 255) * 100));
          bars.push(isMuted ? Math.min(22, Math.round(pct * 0.35)) : pct);
        }
        setFrequencyBars(bars);
      } else {
        setFrequencyBars((prev) => prev.map((v) => Math.max(6, Math.round(v * 0.85))));
      }
      rafId = requestAnimationFrame(updateBars);
    };

    rafId = requestAnimationFrame(updateBars);
    return () => cancelAnimationFrame(rafId);
  }, [isPlaying, isMuted]);

  const seekTo = useCallback((seconds: number) => {
    if (!audioRef.current || !Number.isFinite(seconds)) return;
    audioRef.current.currentTime = Math.max(0, seconds);
    setCurrentTime(audioRef.current.currentTime);
  }, []);

  const toggleMic = useCallback(async () => {
    setMicError(null);
    if (micActive) {
      if (micSourceRef.current) {
        micSourceRef.current.disconnect();
        micSourceRef.current = null;
      }
      if (micStreamRef.current) {
        micStreamRef.current.getTracks().forEach((t) => t.stop());
        micStreamRef.current = null;
      }
      setMicActive(false);
      return;
    }

    try {
      ensureAudioGraph();
      const stream = await navigator.mediaDevices.getUserMedia({audio: true});
      micStreamRef.current = stream;
      if (audioCtxRef.current && analyserRef.current) {
        const micSrc = audioCtxRef.current.createMediaStreamSource(stream);
        // Connect to analyser so voice activity appears in the call meter without echoing to speakers
        micSrc.connect(analyserRef.current);
        micSourceRef.current = micSrc;
      }
      setMicActive(true);
    } catch {
      setMicError('دسترسی میکروفون توسط مرورگر مسدود شده یا دستگاه صوتی یافت نشد.');
      setMicActive(false);
    }
  }, [micActive, ensureAudioGraph]);

  // Turn off mic automatically if voice call ends
  useEffect(() => {
    if (!voiceCallActive && micActive) {
      if (micSourceRef.current) {
        micSourceRef.current.disconnect();
        micSourceRef.current = null;
      }
      if (micStreamRef.current) {
        micStreamRef.current.getTracks().forEach((t) => t.stop());
        micStreamRef.current = null;
      }
      setMicActive(false);
    }
  }, [voiceCallActive, micActive]);

  const unlockAudioAndPlay = useCallback(() => {
    ensureAudioGraph();
    if (audioRef.current && audioRef.current.src) {
      setAudioError(null);
      void audioRef.current.play().catch(() => {
        setAudioError('پخش صوتی با خطا مواجه شد.');
      });
    }
  }, [ensureAudioGraph]);

  return {
    currentTime,
    duration,
    frequencyBars,
    audioError,
    isBuffering,
    micActive,
    micError,
    seekTo,
    toggleMic,
    unlockAudioAndPlay,
  };
}
