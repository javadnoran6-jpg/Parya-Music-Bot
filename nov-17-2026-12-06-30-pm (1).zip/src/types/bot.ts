export type UserRole = 'creator' | 'owner' | 'admin' | 'vip' | 'member';

export type MusicMood =
  | 'شاد'
  | 'غمگین'
  | 'محلی و لری'
  | 'سنتی'
  | 'پاپ'
  | 'نوستالژی'
  | 'آرام';

export interface Track {
  id: string;
  title: string;
  artist: string;
  album?: string;
  durationSec: number;
  streamUrl: string;
  sourceUrl?: string;
  artworkUrl?: string;
  source: 'itunes' | 'deezer' | 'direct' | 'reply';
  mood?: MusicMood;
  requestedBy: string;
  requestedAt: string;
}

export interface GroupMember {
  userId: string;
  name: string;
  username?: string;
  role: UserRole;
  joinedAt: string;
}

export interface GroupSubscription {
  planName: string;
  purchasedAt: string;
  expiresAt: string;
  isActive: boolean;
}

export interface ChatMessage {
  id: string;
  groupId: string;
  senderId: string;
  senderName: string;
  senderRole: UserRole;
  text: string;
  isBot: boolean;
  replyToMessageId?: string;
  replyPreview?: string;
  audioAttachment?: {
    title: string;
    artist?: string;
    url: string;
    durationSec?: number;
  };
  deliveredToRubika?: boolean;
  rubikaMessageId?: string;
  timestamp: string;
}

export interface AutoShutdownConfig {
  enabled: boolean;
  targetTime: string;
  timezoneOffsetMinutes: number;
  stopPollingAlso: boolean;
  nextTriggerIso: string | null;
  lastTriggeredAt?: string | null;
}

export interface SmartPlaylistPreset {
  id: string;
  name: string;
  moods: MusicMood[];
  trackCount: number;
  balanceMode: 'interleaved' | 'shuffled';
  createdAt: string;
}

export interface PlaybackAnalyticsEvent {
  id: string;
  trackId: string;
  title: string;
  artist: string;
  mood?: MusicMood;
  source: Track['source'];
  requestedBy: string;
  timestamp: string;
}

export interface HourlyAnalyticsBucket {
  hour: number;
  label: string;
  tracksPlayed: number;
  commandsCount: number;
  totalActivity: number;
}

export interface GroupAnalyticsResponse {
  groupId: string;
  groupTitle: string;
  tzOffsetMinutes: number;
  hourly: HourlyAnalyticsBucket[];
  summary: {
    totalTracksPlayed: number;
    totalCommands: number;
    peakHour: HourlyAnalyticsBucket | null;
    activeHoursCount: number;
    avgPerActiveHour: number;
  };
  moodBreakdown: Array<{mood: string; count: number}>;
  recentPlays: PlaybackAnalyticsEvent[];
}

export interface GroupState {
  groupId: string;
  title: string;
  rubikaChatId: string;
  ownerId: string;
  ownerName: string;
  publicAccess: 'open' | 'locked';
  voiceCallActive: boolean;
  voiceCallId?: string;
  voiceCallStartedAt?: string;
  volume: number;
  isMuted: boolean;
  isPlaying: boolean;
  currentTrack: Track | null;
  pausedTrack: Track | null;
  pausedPositionSec: number;
  queue: Track[];
  history: Track[];
  playbackEvents?: PlaybackAnalyticsEvent[];
  members: GroupMember[];
  subscription: GroupSubscription;
  autoShutdown?: AutoShutdownConfig;
  savedPlaylists?: SmartPlaylistPreset[];
  messages: ChatMessage[];
}

export interface RubikaApiLog {
  id: string;
  timestamp: string;
  method: string;
  status: 'ok' | 'error' | 'info';
  detail: string;
}

export interface BotConfigState {
  token: string;
  creatorId: string;
  creatorName: string;
  botUsername: string;
  botName: string;
  pollingActive: boolean;
  lastVerifyResult: {
    verified: boolean;
    checkedAt?: string;
    botInfo?: Record<string, unknown>;
    error?: string;
  };
  rubikaMode: 'bot_api_v3' | 'userbot_rubpy';
  activeGroupId: string;
  groups: Record<string, GroupState>;
  apiLogs: RubikaApiLog[];
}

export interface ExportFileEntry {
  path: string;
  language: 'python' | 'yaml' | 'ini' | 'markdown' | 'text';
  title: string;
  description: string;
  content: string;
}
